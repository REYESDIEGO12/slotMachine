/**
 * Pruebas de unidad compartidas del Ciclo 2.
 *
 * @author REYESL - BARRAGANB
 * @version 2026-2
 */
public class SlotMachineCC2Test
{
    /**
     * Verifica que al intercambiar dos ruedas se intercambien
     * sus posiciones.
     */
    public void accordingBBRLShouldSwapWheels()
    {
        SlotMachine slotMachine = new SlotMachine();

        // Agregar dos ruedas
        slotMachine.addWheel(1);
        slotMachine.addWheel(2);

        // Agregar simbolos diferentes
        slotMachine.addSymbol(1, "red");
        slotMachine.addSymbol(2, "blue");

        // Configuracion antes del intercambio
        String before = slotMachine.configuration();

        // Intercambiar las ruedas
        slotMachine.swap(1, 2);

        // Configuracion despues del intercambio
        String after = slotMachine.configuration();

        // La configuracion debe cambiar
        assert !before.equals(after);
    }

    /**
     * Verifica que una rueda bloqueada no pueda girar.
     */
    public void accordingBBRLShouldNotSpinWhenLocked()
    {
        SlotMachine slotMachine = new SlotMachine();

        // Agregar una rueda
        slotMachine.addWheel(1);

        // Agregar varios simbolos
        slotMachine.addSymbol(1, "red");
        slotMachine.addSymbol(1, "blue");
        slotMachine.addSymbol(1, "green");

        // Bloquear la rueda
        slotMachine.lock(1);

        // Guardar configuracion antes de girar
        String before = slotMachine.configuration();

        // Intentar girar la rueda bloqueada
        slotMachine.spin(1, 1);

        // Guardar configuracion despues
        String after = slotMachine.configuration();

        // La configuracion debe permanecer igual
        assert before.equals(after);
    }
}