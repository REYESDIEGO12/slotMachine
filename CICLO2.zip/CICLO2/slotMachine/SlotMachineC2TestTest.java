

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class SlotMachineC2TestTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class SlotMachineC2TestTest
{
    /**
     * Default constructor for test class SlotMachineC2TestTest
     */
    public SlotMachineC2TestTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @AfterEach
    public void tearDown()
    {
    }

    @Test
    public void SwapWorks()
    {
        SlotMachine machibe = new SlotMachine();
        machibe.addWheel(1);
        machibe.addWheel(2);
        machibe.addSymbol(1, "red");
        machibe.addSymbol(1, "blue");
        machibe.addWheel(2);
        machibe.addSymbol(2, "Red");
        machibe.addSymbol(2, "blue");
        machibe.spin();
        machibe.spin();
        machibe.swap(1, 2);
    }
}
