import java.util.ArrayList;

/**
 * Representa una rueda de la maquina tragamonedas.
 *
 * @author
 * @version 2026-2
 */
public class Wheel
{
    private ArrayList<Symbol> symbols;
    private int currentPosition;
    private boolean locked;

    /**
     * Crea una rueda vacia.
     */
    public Wheel()
    {
        symbols = new ArrayList<Symbol>();
        currentPosition = 0;
        locked = false;
    }

    /**
     * Agrega un simbolo a la rueda.
     *
     * @param symbol Simbolo que se desea agregar.
     */
    public void addSymbol(Symbol symbol)
    {
        symbols.add(symbol);
    }

    /**
     * Elimina un simbolo de la rueda.
     *
     * @param color Color del simbolo que se desea eliminar.
     */
    public void delSymbol(String color)
    {
        for (int i = 0; i < symbols.size(); i++) {
            if (symbols.get(i).getColor().equals(color)) {
                symbols.remove(i);
                if (currentPosition >= symbols.size() && !symbols.isEmpty()) {
                    currentPosition = symbols.size() - 1;
                }
                return;
            }
        }
    }

    /**
     * Obtiene el simbolo que esta actualmente visible.
     *
     * @return El simbolo actual.
     */
    public Symbol currentSymbol()
    {
        if (symbols.isEmpty()) {
            return null;
        }
        return symbols.get(currentPosition);
    }

    /**
     * Gira la rueda un numero determinado de pasos.
     *
     * @param steps Numero de pasos que debe girar.
     */
    public void spin(int steps)
    {
        if (locked || symbols.isEmpty()) {
            return;
        }

        currentPosition = (currentPosition + steps) % symbols.size();

        if (currentPosition < 0) {
            currentPosition += symbols.size();
        }
    }

    /**
     * Fija la rueda.
     */
    public void lock()
    {
        locked = true;
    }

    /**
     * Suelta la rueda.
     */
    public void unlock()
    {
        locked = false;
    }

    /**
     * Indica si la rueda esta fijada.
     *
     * @return true si esta fijada, false en caso contrario.
     */
    public boolean isLocked()
    {
        return locked;
    }

    /**
     * Obtiene todos los simbolos de la rueda.
     *
     * @return Lista de simbolos.
     */
    public ArrayList<Symbol> getSymbols()
    {
        return symbols;
    }
}