
/**
 * Representa un simbolo de la maquina tragamonedas.
 * Cada simbolo se identifica mediante un color.
 *
 * @author
 * @version 2026-2
 */
public class Symbol
{
    private String color;

    /**
     * Crea un simbolo con un color determinado.
     *
     * @param color Color del simbolo.
     */
    public Symbol(String color)
    {
        this.color = color;
    }

    /**
     * Obtiene el color del simbolo.
     *
     * @return El color del simbolo.
     */
    public String getColor()
    {
        return color;
    }
}