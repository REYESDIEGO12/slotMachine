import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 * Representa una maquina tragamonedas.
 *
 * @author
 * @version 2026-2
 */
public class SlotMachine
{
    private ArrayList<Wheel> wheels;
    private boolean visible;

    /**
     * Crea una maquina tragamonedas vacia.
     */
    public SlotMachine()
    {
        wheels = new ArrayList<Wheel>();
        visible = false;
    }

    /**
     * Agrega una rueda en una posicion.
     *
     * @param pos Posicion donde se agrega la rueda.
     */
    public void addWheel(int pos)
    {
        if (pos < 1 || pos > wheels.size() + 1) {
            error("Posicion de rueda invalida");
            return;
        }

        wheels.add(pos - 1, new Wheel());
    }

    /**
     * Elimina una rueda.
     *
     * @param pos Posicion de la rueda.
     */
    public void delWheel(int pos)
    {
        if (pos < 1 || pos > wheels.size()) {
            error("Posicion de rueda invalida");
            return;
        }

        wheels.remove(pos - 1);
    }

    /**
     * Agrega un simbolo a una rueda.
     *
     * @param pos Posicion de la rueda.
     * @param color Color del simbolo.
     */
    public void addSymbol(int pos, String color)
    {
        if (pos < 1 || pos > wheels.size()) {
            error("La rueda no existe");
            return;
        }

        wheels.get(pos - 1).addSymbol(new Symbol(color));
    }

    /**
     * Elimina un simbolo de todas las ruedas.
     *
     * @param color Color del simbolo.
     */
    public void delSymbol(String color)
    {
        for (Wheel wheel : wheels) {
            wheel.delSymbol(color);
        }
    }

    /**
     * Gira todas las ruedas un paso.
     */
    public void spin()
    {
        for (Wheel wheel : wheels) {
            wheel.spin(1);
        }
    }

    /**
     * Gira una rueda un paso.
     *
     * @param wheel Posicion de la rueda.
     */
    public void spin(int wheel)
    {
        if (wheel < 1 || wheel > wheels.size()) {
            error("La rueda no existe");
            return;
        }

        wheels.get(wheel - 1).spin(1);
    }

    /**
     * Gira una rueda el numero de pasos indicado.
     *
     * @param wheel Posicion de la rueda.
     * @param steps Numero de pasos.
     */
    public void spin(int wheel, int steps)
    {
        if (wheel < 1 || wheel > wheels.size()) {
            error("La rueda no existe");
            return;
        }

        wheels.get(wheel - 1).spin(steps);
    }

    /**
     * Intercambia dos ruedas.
     *
     * @param wheel1 Primera rueda.
     * @param wheel2 Segunda rueda.
     */
    public void swap(int wheel1, int wheel2)
    {
        if (wheel1 < 1 || wheel1 > wheels.size() ||
            wheel2 < 1 || wheel2 > wheels.size()) {
            error("La rueda no existe");
            return;
        }

        Wheel temporary = wheels.get(wheel1 - 1);
        wheels.set(wheel1 - 1, wheels.get(wheel2 - 1));
        wheels.set(wheel2 - 1, temporary);
    }

    /**
     * Fija una rueda.
     *
     * @param wheel Posicion de la rueda.
     */
    public void lock(int wheel)
    {
        if (wheel < 1 || wheel > wheels.size()) {
            error("La rueda no existe");
            return;
        }

        wheels.get(wheel - 1).lock();
    }

    /**
     * Suelta una rueda.
     *
     * @param wheel Posicion de la rueda.
     */
    public void unlock(int wheel)
    {
        if (wheel < 1 || wheel > wheels.size()) {
            error("La rueda no existe");
            return;
        }

        wheels.get(wheel - 1).unlock();
    }

    /**
     * Deja la maquina en una configuracion dada.
     *
     * @param symbols Colores que deben quedar visibles.
     */
    public void spin(String[] symbols)
    {
        if (symbols == null || symbols.length != wheels.size()) {
            error("Configuracion invalida");
            return;
        }

        for (int i = 0; i < wheels.size(); i++) {
            placeSymbol(i + 1, symbols[i]);
        }
    }

    /**
     * Coloca un simbolo especifico en una rueda.
     *
     * @param wheel Posicion de la rueda.
     * @param symbol Color del simbolo.
     */
    private void placeSymbol(int wheel, String symbol)
    {
        Wheel selected = wheels.get(wheel - 1);
        ArrayList<Symbol> symbols = selected.getSymbols();

        int current = findCurrentPosition(selected);

        for (int i = 0; i < symbols.size(); i++) {
            if (symbols.get(i).getColor().equals(symbol)) {
                int steps = i - current;
                selected.spin(steps);
                return;
            }
        }

        error("El simbolo no existe");
    }

    /**
     * Obtiene los simbolos actualmente visibles.
     *
     * @return Arreglo con los colores.
     */
    public String[] symbols()
    {
        String[] result = new String[wheels.size()];

        for (int i = 0; i < wheels.size(); i++) {
            Symbol symbol = wheels.get(i).currentSymbol();

            if (symbol == null) {
                result[i] = null;
            } else {
                result[i] = symbol.getColor();
            }
        }

        return result;
    }

    /**
     * Obtiene la configuracion actual.
     *
     * @return Cadena con los colores.
     */
    public String configuration()
    {
        String result = "";

        for (String color : symbols()) {
            if (color != null) {
                if (!result.equals("")) {
                    result += " ";
                }

                result += color;
            }
        }

        return result;
    }

    /**
     * Indica cuantos simbolos diferentes estan visibles.
     *
     * @return Numero de simbolos diferentes.
     */
    public int distinctSymbols()
    {
        ArrayList<String> colors = new ArrayList<String>();

        for (String color : symbols()) {
            if (color != null && !colors.contains(color)) {
                colors.add(color);
            }
        }

        return colors.size();
    }

    /**
     * Indica si la configuracion actual es ganadora.
     *
     * @return true si todos los simbolos son iguales.
     */
    public boolean isJackpot()
    {
        if (wheels.isEmpty()) {
            return false;
        }

        String first = null;

        for (String color : symbols()) {
            if (color == null) {
                return false;
            }

            if (first == null) {
                first = color;
            } else if (!first.equals(color)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Hace visible el simulador.
     */
    public void makeVisible()
    {
        visible = true;
    }

    /**
     * Hace invisible el simulador.
     */
    public void makeInvisible()
    {
        visible = false;
    }

    /**
     * Termina el simulador.
     */
    public void exit()
    {
        visible = false;
    }

    /**
     * Muestra un mensaje si la maquina esta visible.
     *
     * @param message Mensaje de error.
     */
    private void error(String message)
    {
        if (visible) {
            JOptionPane.showMessageDialog(null, message);
        }
    }

    /**
     * Encuentra la posicion actual de una rueda.
     *
     * @param wheel Rueda que se consulta.
     * @return Posicion actual.
     */
    private int findCurrentPosition(Wheel wheel)
    {
        ArrayList<Symbol> symbols = wheel.getSymbols();
        Symbol current = wheel.currentSymbol();

        for (int i = 0; i < symbols.size(); i++) {
            if (symbols.get(i) == current) {
                return i;
            }
        }

        return 0;
    }
}