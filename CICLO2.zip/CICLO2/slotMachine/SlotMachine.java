import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 * Representa una maquina tragamonedas.
 *
 * @author
 * @version 2026-2
 */
public class SlotMachine
{
    private ArrayList<Wheel> wheels;
    private ArrayList<String> symbols;
    private Rectangle machine;
    private boolean visible;
    private boolean successful;

    /**
     * Crea una maquina tragamonedas vacia.
     */
    public SlotMachine()
    {
        wheels = new ArrayList<Wheel>();
        symbols = new ArrayList<String>();

        machine = new Rectangle();
        machine.changeColor("magenta");
        machine.changeSize(180, 270);
        machine.moveHorizontal(-55);
        machine.moveVertical(35);

        visible = false;
        successful = true;
    }

    /**
     * Adiciona una rueda en la posicion indicada.
     *
     * @param pos posicion de la rueda.
     */
    public void addWheel(int pos)
    {
        pos = normalizePosition(pos, wheels.size() + 1);

        Wheel wheel = new Wheel();

        for (int i = 0; i < symbols.size(); i++) {
            wheel.addSymbol(i + 1,
                            new Symbol(symbols.get(i)));
        }

        wheels.add(pos - 1, wheel);

        repositionWheels();

        wheel.setVisible(visible);

        updateAppearance();

        successful = true;
    }

    /**
     * Elimina una rueda.
     *
     * @param pos posicion de la rueda.
     */
    public void delWheel(int pos)
    {
        if (wheels.isEmpty()) {
            fail("No hay ruedas para eliminar.");
            return;
        }

        if (pos < 1 || pos > wheels.size()) {
            fail("La posicion de la rueda no es valida.");
            return;
        }

        wheels.get(pos - 1).setVisible(false);
        wheels.remove(pos - 1);

        repositionWheels();
        updateAppearance();

        successful = true;
    }

    /**
     * Intercambia dos ruedas.
     *
     * @param wheel1 primera rueda.
     * @param wheel2 segunda rueda.
     */
    public void swap(int wheel1, int wheel2)
    {
        if (wheels.isEmpty()) {
            fail("No hay ruedas para intercambiar.");
            return;
        }

        if (wheel1 < 1 || wheel1 > wheels.size()
            || wheel2 < 1 || wheel2 > wheels.size()) {
            fail("La posicion de una rueda no es valida.");
            return;
        }

        Wheel first = wheels.get(wheel1 - 1);
        Wheel second = wheels.get(wheel2 - 1);

        wheels.set(wheel1 - 1, second);
        wheels.set(wheel2 - 1, first);

        repositionWheels();
        updateAppearance();

        successful = true;
    }

    /**
     * Fija una rueda para impedir que gire.
     *
     * @param wheel posicion de la rueda.
     */
    public void lock(int wheel)
    {
        if (wheels.isEmpty()) {
            fail("No hay ruedas para fijar.");
            return;
        }

        if (wheel < 1 || wheel > wheels.size()) {
            fail("La posicion de la rueda no es valida.");
            return;
        }

        wheels.get(wheel - 1).lock();

        successful = true;
    }

    /**
     * Suelta una rueda para permitir que gire.
     *
     * @param wheel posicion de la rueda.
     */
    public void unlock(int wheel)
    {
        if (wheels.isEmpty()) {
            fail("No hay ruedas para soltar.");
            return;
        }

        if (wheel < 1 || wheel > wheels.size()) {
            fail("La posicion de la rueda no es valida.");
            return;
        }

        wheels.get(wheel - 1).unlock();

        successful = true;
    }

    /**
     * Adiciona un simbolo a la maquina.
     *
     * @param pos posicion del simbolo.
     * @param color color del simbolo.
     */
    public void addSymbol(int pos, String color)
    {
        if (!validColor(color)) {
            fail("El color del simbolo no es valido.");
            return;
        }

        if (symbols.contains(color)) {
            fail("El simbolo ya existe.");
            return;
        }

        pos = normalizePosition(pos, symbols.size() + 1);

        symbols.add(pos - 1, color);

        for (Wheel wheel : wheels) {
            wheel.addSymbol(pos, new Symbol(color));
        }

        updateAppearance();

        successful = true;
    }

    /**
     * Elimina un simbolo de la maquina.
     *
     * @param symbol color del simbolo.
     */
    public void delSymbol(String symbol)
    {
        if (!symbols.contains(symbol)) {
            fail("El simbolo no existe.");
            return;
        }

        symbols.remove(symbol);

        for (Wheel wheel : wheels) {
            wheel.delSymbol(symbol);
        }

        updateAppearance();

        successful = true;
    }

    /**
     * Coloca un simbolo como visible en una rueda.
     *
     * @param wheel posicion de la rueda.
     * @param symbol color del simbolo.
     */
    public void placeSymbol(int wheel, String symbol)
    {
        if (wheels.isEmpty()) {
            fail("No hay ruedas en la maquina.");
            return;
        }

        if (!symbols.contains(symbol)) {
            fail("El simbolo no existe.");
            return;
        }

        if (wheel < 1 || wheel > wheels.size()) {
            fail("La posicion de la rueda no es valida.");
            return;
        }

        if (!wheels.get(wheel - 1).placeSymbol(symbol)) {
            fail("El simbolo no existe en la rueda.");
            return;
        }

        updateAppearance();

        successful = true;
    }

    /**
     * Gira una rueda una posicion.
     *
     * @param wheel posicion de la rueda.
     */
    public void spinWheel(int wheel)
    {
        if (wheels.isEmpty()) {
            fail("No hay ruedas en la maquina.");
            return;
        }

        if (wheel < 1 || wheel > wheels.size()) {
            fail("La posicion de la rueda no es valida.");
            return;
        }

        wheels.get(wheel - 1).spin();

        updateAppearance();

        successful = true;
    }

    /**
     * Gira todas las ruedas.
     */
    public void spin()
    {
        if (wheels.isEmpty()) {
            fail("No hay ruedas en la maquina.");
            return;
        }

        for (Wheel wheel : wheels) {
            wheel.spin();
        }

        updateAppearance();

        successful = true;
    }

    /**
     * Gira una rueda un numero determinado de pasos.
     *
     * @param wheel posicion de la rueda.
     * @param steps cantidad de pasos.
     */
    public void spin(int wheel, int steps)
    {
        if (wheels.isEmpty()) {
            fail("No hay ruedas en la maquina.");
            return;
        }

        if (wheel < 1 || wheel > wheels.size()) {
            fail("La posicion de la rueda no es valida.");
            return;
        }

        if (steps < 0) {
            fail("El numero de pasos no puede ser negativo.");
            return;
        }

        Wheel selected = wheels.get(wheel - 1);

        for (int i = 0; i < steps; i++) {
            selected.spin();

            updateAppearance();

            if (visible) {
                try {
                    Thread.sleep(300);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }

        successful = true;
    }

    /**
     * Deja la maquina en una configuracion determinada.
     *
     * @param setSymbols colores que deben quedar visibles
     *                   en cada rueda.
     */
    public void spin(String[] setSymbols)
    {
        if (setSymbols == null) {
            fail("La configuracion no puede ser nula.");
            return;
        }

        if (setSymbols.length != wheels.size()) {
            fail("La cantidad de simbolos no coincide con las ruedas.");
            return;
        }

        for (int i = 0; i < setSymbols.length; i++) {

            if (!symbols.contains(setSymbols[i])) {
                fail("El simbolo no existe.");
                return;
            }

            if (wheels.get(i).isLocked()) {
                if (!wheels.get(i).getVisibleSymbol().getColor()
                    .equals(setSymbols[i])) {
                    fail("Una rueda fijada no puede cambiar.");
                    return;
                }
            }
        }

        for (int i = 0; i < setSymbols.length; i++) {
            wheels.get(i).placeSymbol(setSymbols[i]);
        }

        updateAppearance();

        successful = true;
    }

    /**
     * Retorna los simbolos de la maquina.
     *
     * @return colores de los simbolos.
     */
    public String symbols()
    {
        String result = "";

        for (String symbol : symbols) {
            if (!result.isEmpty()) {
                result += " ";
            }

            result += symbol;
        }

        return result;
    }

    /**
     * Retorna la cantidad de simbolos diferentes.
     *
     * @return cantidad de simbolos.
     */
    public int distinctSymbols()
    {
        return symbols.size();
    }

    /**
     * Retorna la configuracion visible de la maquina.
     *
     * @return colores visibles de izquierda a derecha.
     */
    public String configuration()
    {
        String result = "";

        for (Wheel wheel : wheels) {
            Symbol symbol = wheel.getVisibleSymbol();

            if (symbol != null) {
                if (!result.isEmpty()) {
                    result += " ";
                }

                result += symbol.getColor();
            }
        }

        return result;
    }

    /**
     * Verifica si la configuracion es ganadora.
     *
     * @return true si todas las ruedas muestran el mismo simbolo.
     */
    public boolean isJackpot()
    {
        boolean jackpot = isJackpotConfiguration();

        updateAppearance();

        return jackpot;
    }

    /**
     * Hace visible el simulador.
     */
    public void makeVisible()
    {
        visible = true;

        Canvas.getCanvas().setVisible(true);

        machine.makeVisible();

        for (Wheel wheel : wheels) {
            wheel.setVisible(true);
        }

        updateAppearance();

        successful = true;
    }

    /**
     * Hace invisible el simulador.
     */
    public void makeInvisible()
    {
        for (Wheel wheel : wheels) {
            wheel.setVisible(false);
        }

        machine.makeInvisible();

        visible = false;

        successful = true;
    }

    /**
     * Termina el simulador.
     */
    public void exit()
    {
        makeInvisible();

        Canvas.getCanvas().setVisible(false);

        successful = true;
    }

    /**
     * Indica si la ultima operacion fue exitosa.
     *
     * @return true si fue exitosa.
     */
    public boolean ok()
    {
        return successful;
    }

    /**
     * Ajusta una posicion al rango permitido.
     *
     * @param pos posicion solicitada.
     * @param maximum valor maximo.
     * @return posicion ajustada.
     */
    private int normalizePosition(int pos, int maximum)
    {
        if (pos < 1) {
            return 1;
        }

        if (pos > maximum) {
            return maximum;
        }

        return pos;
    }

    /**
     * Verifica si el color es soportado por shapes.
     *
     * @param color color que se desea validar.
     * @return true si el color es valido.
     */
    private boolean validColor(String color)
    {
        return "red".equals(color)
            || "yellow".equals(color)
            || "blue".equals(color)
            || "green".equals(color)
            || "magenta".equals(color)
            || "black".equals(color);
    }

    /**
     * Registra una operacion fallida.
     *
     * @param message mensaje que se muestra.
     */
    private void fail(String message)
    {
        successful = false;

        if (visible) {
            JOptionPane.showMessageDialog(null, message);
        }
    }

    /**
     * Reorganiza las ruedas visualmente.
     */
    private void repositionWheels()
    {
        int x = 40;
        int y = 80;

        for (Wheel wheel : wheels) {
            wheel.setPosition(x, y);
            x += 80;
        }
    }

    /**
     * Cambia la apariencia de la maquina.
     */
    private void updateAppearance()
    {
        if (isJackpotConfiguration()) {
            machine.changeColor("green");
        } else {
            machine.changeColor("magenta");
        }

        if (visible) {
            for (Wheel wheel : wheels) {
                wheel.setVisible(true);
            }
        }
    }

    /**
     * Verifica internamente si existe jackpot.
     *
     * @return true si todas las ruedas muestran el mismo simbolo.
     */
    private boolean isJackpotConfiguration()
    {
        if (wheels.isEmpty() || symbols.isEmpty()) {
            return false;
        }

        Symbol first = wheels.get(0).getVisibleSymbol();

        if (first == null) {
            return false;
        }

        for (Wheel wheel : wheels) {
            Symbol current = wheel.getVisibleSymbol();

            if (current == null) {
                return false;
            }

            if (!first.getColor().equals(current.getColor())) {
                return false;
            }
        }

        return true;
    }
}