/**
 * Pruebas de unidad para el Ciclo 2 de SlotMachine.
 *
 * @author
 * @version 2026-2
 */
public class SlotMachineC2Test
{
    /**
     * Prueba que dos ruedas se puedan intercambiar.
     */
    public void testSwapWorks()
    {
        SlotMachine machine = createMachine();

        machine.spin(2);

        assert machine.configuration().equals("red blue");

        machine.swap(1, 2);

        assert machine.configuration().equals("blue red");
    }

    /**
     * Prueba que una rueda fijada no pueda girar.
     */
    public void testLockedWheelDoesNotSpin()
    {
        SlotMachine machine = createMachine();

        machine.spin(2);

        assert machine.configuration().equals("red blue");

        machine.lock(2);
        machine.spin(2);

        assert machine.configuration().equals("red blue");
    }

    /**
     * Prueba que una rueda se pueda soltar y volver a girar.
     */
    public void testUnlockedWheelSpins()
    {
        SlotMachine machine = createMachine();

        machine.spin(2);
        machine.lock(2);
        machine.spin(2);

        assert machine.configuration().equals("red blue");

        machine.unlock(2);
        machine.spin(2);

        assert machine.configuration().equals("red red");
    }

    /**
     * Prueba que una rueda pueda girar varios pasos.
     */
    public void testSpinSeveralSteps()
    {
        SlotMachine machine = createMachine();

        machine.spin(1, 2);

        assert machine.configuration().equals("green red");
    }

    /**
     * Prueba que la maquina pueda llegar a una configuracion dada.
     */
    public void testConfigurationWorks()
    {
        SlotMachine machine = createMachine();

        machine.spin(new String[]{"blue", "green"});

        assert machine.configuration().equals("blue green");
    }

    /**
     * Prueba que una rueda inexistente no pueda ser utilizada.
     */
    public void testInvalidWheelDoesNothing()
    {
        SlotMachine machine = createMachine();

        String before = machine.configuration();

        machine.spin(5);

        assert machine.configuration().equals(before);
    }

    /**
     * Crea una maquina preparada para las pruebas.
     *
     * @return Maquina con dos ruedas y tres simbolos en cada rueda.
     */
    private SlotMachine createMachine()
    {
        SlotMachine machine = new SlotMachine();

        machine.addWheel(1);
        machine.addWheel(2);

        machine.addSymbol(1, "red");
        machine.addSymbol(1, "blue");
        machine.addSymbol(1, "green");

        machine.addSymbol(2, "red");
        machine.addSymbol(2, "blue");
        machine.addSymbol(2, "green");

        return machine;
    }
}