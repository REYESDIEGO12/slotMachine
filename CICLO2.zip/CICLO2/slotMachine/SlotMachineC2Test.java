import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Pruebas de unidad para el Ciclo 2 de SlotMachine.
 *
 * @author
 * @version 2026-2
 */
public class SlotMachineC2Test
{
    /**
     * Verifica que al intercambiar dos ruedas se intercambie
     * su configuracion.
     */
    @Test
    public void accordingBBRLShouldSwapWheels()
    {
        SlotMachine slotMachine = new SlotMachine();

        slotMachine.addSymbol(1, "red");
        slotMachine.addSymbol(2, "blue");

        slotMachine.addWheel(1);
        slotMachine.addWheel(2);

        slotMachine.placeSymbol(1, "red");
        slotMachine.placeSymbol(2, "blue");

        String before = slotMachine.configuration();

        slotMachine.swap(1, 2);

        String after = slotMachine.configuration();

        assertEquals("red blue", before);
        assertEquals("blue red", after);
    }

    /**
     * Verifica que una rueda bloqueada no pueda girar.
     */
    @Test
    public void accordingBBRLShouldNotSpinWhenLocked()
    {
        SlotMachine slotMachine = new SlotMachine();

        slotMachine.addSymbol(1, "red");
        slotMachine.addSymbol(2, "blue");
        slotMachine.addSymbol(3, "green");

        slotMachine.addWheel(1);

        slotMachine.placeSymbol(1, "red");

        slotMachine.lock(1);

        String before = slotMachine.configuration();

        slotMachine.spin(1, 1);

        String after = slotMachine.configuration();

        assertEquals("red", before);
        assertEquals("red", after);
    }

    /**
     * Verifica que una rueda desbloqueada pueda girar.
     */
    @Test
    public void accordingBBRLShouldSpinWhenUnlocked()
    {
        SlotMachine slotMachine = new SlotMachine();

        slotMachine.addSymbol(1, "red");
        slotMachine.addSymbol(2, "blue");

        slotMachine.addWheel(1);

        slotMachine.placeSymbol(1, "red");

        slotMachine.lock(1);
        slotMachine.unlock(1);

        slotMachine.spin(1, 1);

        assertEquals("blue", slotMachine.configuration());
    }

    /**
     * Verifica que una rueda gire el numero indicado de pasos.
     */
    @Test
    public void accordingBBRLShouldSpinTheSpecifiedNumberOfSteps()
    {
        SlotMachine slotMachine = new SlotMachine();

        slotMachine.addSymbol(1, "red");
        slotMachine.addSymbol(2, "blue");
        slotMachine.addSymbol(3, "green");

        slotMachine.addWheel(1);

        slotMachine.placeSymbol(1, "red");

        slotMachine.spin(1, 2);

        assertEquals("green", slotMachine.configuration());
    }

    /**
     * Verifica que la maquina pueda quedar en una configuracion dada.
     */
    @Test
    public void accordingBBRLShouldSetTheSpecifiedConfiguration()
    {
        SlotMachine slotMachine = new SlotMachine();

        slotMachine.addSymbol(1, "red");
        slotMachine.addSymbol(2, "blue");
        slotMachine.addSymbol(3, "green");

        slotMachine.addWheel(1);
        slotMachine.addWheel(2);
        slotMachine.addWheel(3);

        String[] setSymbols = {"green", "blue", "red"};

        slotMachine.spin(setSymbols);

        assertEquals(
            "green blue red",
            slotMachine.configuration()
        );
    }
}