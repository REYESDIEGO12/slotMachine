import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 * Representa una maquina tragamonedas.
 *
 * @author
 * @version 2026-2
 */
public class SlotMachine
{
    private ArrayList<Wheel> wheels;
    private ArrayList<String> symbols;
    private Rectangle machine;
    private boolean visible;
    private boolean successful;

    /**
     * Crea una maquina tragamonedas vacia.
     */
    public SlotMachine()
    {
        wheels = new ArrayList<Wheel>();
        symbols = new ArrayList<String>();

        machine = new Rectangle();
        machine.changeColor("magenta");
        machine.changeSize(180, 270);
        machine.moveHorizontal(-55);
        machine.moveVertical(35);

        visible = false;
        successful = true;
    }

    /**
     * Adiciona una rueda en la posicion indicada.
     *
     * @param pos posicion de la rueda.
     */
    public void addWheel(int pos)
    {
        pos = normalizePosition(pos, wheels.size() + 1);

        Wheel wheel = new Wheel();

        for (int i = 0; i < symbols.size(); i++) {
            wheel.addSymbol(i + 1,
                            new Symbol(symbols.get(i)));
        }

        wheels.add(pos - 1, wheel);

        repositionWheels();

        wheel.setVisible(visible);

        updateAppearance();

        successful = true;
    }

    /**
     * Elimina una rueda.
     *
     * @param pos posicion de la rueda.
     */
    public void delWheel(int pos)
    {
        if (wheels.isEmpty()) {
            fail("No hay ruedas para eliminar.");
            return;
        }

        pos = normalizePosition(pos, wheels.size());

        wheels.get(pos - 1).setVisible(false);
        wheels.remove(pos - 1);

        repositionWheels();
        updateAppearance();

        successful = true;
    }

    /**
     * Adiciona un simbolo a la maquina.
     *
     * @param pos posicion del simbolo.
     * @param color color del simbolo.
     */
    public void addSymbol(int pos, String color)
    {
        if (!validColor(color)) {
            fail("El color del simbolo no es valido.");
            return;
        }

        if (symbols.contains(color)) {
            fail("El simbolo ya existe.");
            return;
        }

        pos = normalizePosition(pos, symbols.size() + 1);

        symbols.add(pos - 1, color);

        for (Wheel wheel : wheels) {
            wheel.addSymbol(pos, new Symbol(color));
        }

        updateAppearance();

        successful = true;
    }

    /**
     * Elimina un simbolo de la maquina.
     *
     * @param symbol color del simbolo.
     */
    public void delSymbol(String symbol)
    {
        if (!symbols.contains(symbol)) {
            fail("El simbolo no existe.");
            return;
        }

        symbols.remove(symbol);

        for (Wheel wheel : wheels) {
            wheel.delSymbol(symbol);
        }

        updateAppearance();

        successful = true;
    }

    /**
     * Coloca un simbolo como visible en una rueda.
     *
     * @param wheel posicion de la rueda.
     * @param symbol color del simbolo.
     */
    public void placeSymbol(int wheel, String symbol)
    {
        if (wheels.isEmpty()) {
            fail("No hay ruedas en la maquina.");
            return;
        }

        if (!symbols.contains(symbol)) {
            fail("El simbolo no existe.");
            return;
        }

        wheel = normalizePosition(wheel, wheels.size());

        if (!wheels.get(wheel - 1).placeSymbol(symbol)) {
            fail("El simbolo no existe en la rueda.");
            return;
        }

        updateAppearance();

        successful = true;
    }

    /**
     * Gira una rueda.
     *
     * @param wheel posicion de la rueda.
     */
    public void spinWheel(int wheel)
    {
        if (wheels.isEmpty()) {
            fail("No hay ruedas en la maquina.");
            return;
        }

        wheel = normalizePosition(wheel, wheels.size());

        wheels.get(wheel - 1).spin();

        updateAppearance();

        successful = true;
    }

    /**
     * Gira todas las ruedas.
     */
    public void spin()
    {
        if (wheels.isEmpty()) {
            fail("No hay ruedas en la maquina.");
            return;
        }

        for (Wheel wheel : wheels) {
            wheel.spin();
        }

        updateAppearance();

        successful = true;
    }

    /**
     * Retorna los simbolos de la maquina.
     *
     * @return colores de los simbolos.
     */
    public String symbols()
    {
        String result = "";

        for (String symbol : symbols) {
            if (!result.isEmpty()) {
                result += " ";
            }

            result += symbol;
        }

        return result;
    }

    /**
     * Retorna la cantidad de simbolos diferentes.
     *
     * @return cantidad de simbolos.
     */
    public int distinctSymbols()
    {
        return symbols.size();
    }

    /**
     * Retorna la configuracion visible de la maquina.
     *
     * @return colores visibles de izquierda a derecha.
     */
    public String configuration()
    {
        String result = "";

        for (Wheel wheel : wheels) {
            Symbol symbol = wheel.getVisibleSymbol();

            if (symbol != null) {
                if (!result.isEmpty()) {
                    result += " ";
                }

                result += symbol.getColor();
            }
        }

        return result;
    }

    /**
     * Verifica si la configuracion es ganadora.
     *
     * @return true si todas las ruedas muestran el mismo simbolo.
     */
    public boolean isJackpot()
    {
        boolean jackpot = isJackpotConfiguration();

        updateAppearance();

        return jackpot;
    }

    /**
     * Hace visible el simulador.
     */
    public void makeVisible()
    {
        visible = true;

        Canvas.getCanvas().setVisible(true);

        machine.makeVisible();

        for (Wheel wheel : wheels) {
            wheel.setVisible(true);
        }

        updateAppearance();

        successful = true;
    }

    /**
     * Hace invisible el simulador.
     */
    public void makeInvisible()
    {
        for (Wheel wheel : wheels) {
            wheel.setVisible(false);
        }

        machine.makeInvisible();

        visible = false;

        successful = true;
    }

    /**
     * Termina el simulador.
     */
    public void exit()
    {
        makeInvisible();

        Canvas.getCanvas().setVisible(false);

        successful = true;
    }

    /**
     * Indica si la ultima operacion fue exitosa.
     *
     * @return true si fue exitosa.
     */
    public boolean ok()
    {
        return successful;
    }

    /**
     * Ajusta una posicion al rango permitido.
     *
     * @param pos posicion solicitada.
     * @param maximum valor maximo.
     * @return posicion ajustada.
     */
    private int normalizePosition(int pos, int maximum)
    {
        if (pos < 1) {
            return 1;
        }

        if (pos > maximum) {
            return maximum;
        }

        return pos;
    }

    /**
     * Verifica si el color es soportado por shapes.
     *
     * @param color color que se desea validar.
     * @return true si el color es valido.
     */
    private boolean validColor(String color)
    {
        return "red".equals(color)
            || "yellow".equals(color)
            || "blue".equals(color)
            || "green".equals(color)
            || "magenta".equals(color)
            || "black".equals(color);
    }

    /**
     * Registra una operacion fallida.
     *
     * @param message mensaje que se muestra.
     */
    private void fail(String message)
    {
        successful = false;

        if (visible) {
            JOptionPane.showMessageDialog(null, message);
        }
    }

    /**
     * Reorganiza las ruedas visualmente.
     */
    private void repositionWheels()
    {
        int x = 40;
        int y = 80;

        for (Wheel wheel : wheels) {
            wheel.setPosition(x, y);
            x += 80;
        }
    }

    /**
     * Cambia la apariencia de la maquina.
     * Primero se dibuja la maquina y despues las ruedas
     * para evitar que el rectangulo cubra los simbolos.
     */
    private void updateAppearance()
    {
        if (isJackpotConfiguration()) {
            machine.changeColor("green");
        } else {
            machine.changeColor("magenta");
        }

        if (visible) {
            for (Wheel wheel : wheels) {
                wheel.setVisible(true);
            }
        }
    }

    /**
     * Verifica internamente si existe jackpot.
     *
     * @return true si todas las ruedas muestran el mismo simbolo.
     */
    private boolean isJackpotConfiguration()
    {
        if (wheels.isEmpty() || symbols.isEmpty()) {
            return false;
        }

        Symbol first = wheels.get(0).getVisibleSymbol();

        if (first == null) {
            return false;
        }

        for (Wheel wheel : wheels) {
            Symbol current = wheel.getVisibleSymbol();

            if (current == null) {
                return false;
            }

            if (!first.getColor().equals(current.getColor())) {
                return false;
            }
        }

        return true;
    }
}