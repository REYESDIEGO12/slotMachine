/**
 * Representa un simbolo de la maquina tragamonedas.
 * Cada simbolo se identifica mediante un color.
 *
 * @author
 * @version 2026-2
 */
public class Symbol
{
    private String color;
    private Circle figure;
    private int xPosition;
    private int yPosition;

    /**
     * Crea un simbolo con el color indicado.
     *
     * @param color color del simbolo.
     */
    public Symbol(String color)
    {
        this.color = color;
        figure = new Circle();
        figure.changeColor(color);
        figure.changeSize(40);

        xPosition = 20;
        yPosition = 15;
    }

    /**
     * Retorna el color del simbolo.
     *
     * @return color del simbolo.
     */
    public String getColor()
    {
        return color;
    }

    /**
     * Hace visible el simbolo.
     */
    public void makeVisible()
    {
        figure.makeVisible();
    }

    /**
     * Hace invisible el simbolo.
     */
    public void makeInvisible()
    {
        figure.makeInvisible();
    }

    /**
     * Mueve el simbolo a una posicion.
     *
     * @param x nueva posicion horizontal.
     * @param y nueva posicion vertical.
     */
    public void moveTo(int x, int y)
    {
        figure.moveHorizontal(x - xPosition);
        figure.moveVertical(y - yPosition);

        xPosition = x;
        yPosition = y;
    }
}