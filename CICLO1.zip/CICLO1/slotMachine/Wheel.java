import java.util.ArrayList;

/**
 * Representa una rueda de la maquina tragamonedas.
 * Una rueda contiene varios simbolos y mantiene
 * uno de ellos como simbolo visible.
 *
 * @author
 * @version 2026-2
 */
public class Wheel
{
    private ArrayList<Symbol> symbols;
    private int visible;
    private Rectangle window;
    private int xPosition;
    private int yPosition;
    private boolean isVisible;

    /**
     * Crea una rueda vacia.
     */
    public Wheel()
    {
        symbols = new ArrayList<Symbol>();
        visible = 0;

        xPosition = 40;
        yPosition = 80;

        isVisible = false;

        window = new Rectangle();
        window.changeColor("black");
        window.changeSize(60, 60);
        window.moveHorizontal(-30);
        window.moveVertical(65);
    }

    /**
     * Adiciona un simbolo en la posicion indicada.
     * Las posiciones comienzan en 1.
     *
     * @param pos posicion del simbolo.
     * @param symbol simbolo que se adiciona.
     */
    public void addSymbol(int pos, Symbol symbol)
    {
        if (symbol == null) {
            return;
        }

        if (pos < 1) {
            pos = 1;
        }

        if (pos > symbols.size() + 1) {
            pos = symbols.size() + 1;
        }

        symbols.add(pos - 1, symbol);

        symbol.moveTo(xPosition + 10, yPosition + 10);

        if (symbols.size() == 1) {
            visible = 0;
        }

        updateVisibility();
    }

    /**
     * Elimina un simbolo por su color.
     *
     * @param color color del simbolo.
     * @return true si se elimino el simbolo.
     */
    public boolean delSymbol(String color)
    {
        for (int i = 0; i < symbols.size(); i++) {
            if (symbols.get(i).getColor().equals(color)) {

                symbols.get(i).makeInvisible();
                symbols.remove(i);

                if (symbols.isEmpty()) {
                    visible = 0;
                } else if (visible >= symbols.size()) {
                    visible = 0;
                }

                updateVisibility();

                return true;
            }
        }

        return false;
    }

    /**
     * Coloca un simbolo determinado como visible.
     *
     * @param color color del simbolo.
     * @return true si el simbolo existe.
     */
    public boolean placeSymbol(String color)
    {
        for (int i = 0; i < symbols.size(); i++) {
            if (symbols.get(i).getColor().equals(color)) {
                visible = i;
                updateVisibility();
                return true;
            }
        }

        return false;
    }

    /**
     * Gira la rueda una posicion.
     */
    public void spin()
    {
        if (!symbols.isEmpty()) {
            visible++;

            if (visible >= symbols.size()) {
                visible = 0;
            }

            updateVisibility();
        }
    }

    /**
     * Retorna el simbolo visible.
     *
     * @return simbolo visible o null si la rueda esta vacia.
     */
    public Symbol getVisibleSymbol()
    {
        if (symbols.isEmpty()) {
            return null;
        }

        return symbols.get(visible);
    }

    /**
     * Retorna los simbolos de la rueda en orden.
     *
     * @return colores de los simbolos.
     */
    public String symbols()
    {
        String result = "";

        for (Symbol symbol : symbols) {
            if (!result.isEmpty()) {
                result += " ";
            }

            result += symbol.getColor();
        }

        return result;
    }

    /**
     * Retorna la cantidad de simbolos.
     *
     * @return cantidad de simbolos.
     */
    public int size()
    {
        return symbols.size();
    }

    /**
     * Verifica si la rueda contiene un simbolo.
     *
     * @param color color que se busca.
     * @return true si existe.
     */
    public boolean contains(String color)
    {
        for (Symbol symbol : symbols) {
            if (symbol.getColor().equals(color)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Hace visible o invisible la rueda.
     *
     * @param visible estado de visibilidad.
     */
    public void setVisible(boolean visible)
    {
        isVisible = visible;

        if (visible) {
            window.makeVisible();
            updateVisibility();
        } else {
            window.makeInvisible();
            hideSymbols();
        }
    }

    /**
     * Cambia la posicion de la rueda.
     *
     * @param x nueva posicion horizontal.
     * @param y nueva posicion vertical.
     */
    public void setPosition(int x, int y)
    {
        int horizontal = x - xPosition;
        int vertical = y - yPosition;

        window.moveHorizontal(horizontal);
        window.moveVertical(vertical);

        xPosition = x;
        yPosition = y;

        for (Symbol symbol : symbols) {
            symbol.moveTo(xPosition + 10, yPosition + 10);
        }

        updateVisibility();
    }

    /**
     * Actualiza la visibilidad del simbolo seleccionado.
     */
    private void updateVisibility()
    {
        hideSymbols();

        if (isVisible && !symbols.isEmpty()) {
            symbols.get(visible).makeVisible();
        }
    }

    /**
     * Oculta todos los simbolos.
     */
    private void hideSymbols()
    {
        for (Symbol symbol : symbols) {
            symbol.makeInvisible();
        }
    }
}