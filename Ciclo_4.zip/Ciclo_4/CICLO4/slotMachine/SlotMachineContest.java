import java.util.ArrayList;

/**
 * Solucionador y simulador del concurso Slot Machine (ICPC 2025 Baku).
 * 
 * Cumple con las restricciones de diseno:
 * 1. SlotMachine se usa para simular y como testing tool de la maraton, no para resolver internamente.
 * 2. Metodos permitidos como testing tool: SlotMachine(n), spin(wheel, steps) y distinctSymbols().
 * 3. Metodos permitidos como simulador: makeVisible() y makeInvisible().
 * 4. SlotMachine permanece invisible en solve y visible en simulate.
 * 
 * @author Reyes y Barragan
 * @version 2026-2
 */
public class SlotMachineContest {
    private SlotMachine machine;

    /**
     * Constructor de SlotMachineContest.
     */
    public SlotMachineContest() {
        machine = null;
    }

    /**
     * Resuelve el problema de la maraton para una maquina de n ruedas y n simbolos.
     * La maquina permanece invisible durante la resolucion.
     * 
     * @param n tamano de la maquina (3 <= n <= 50).
     * @return secuencia de acciones [wheel, steps] necesarias para ganar.
     */
    public int[][] solve(int n) {
        machine = new SlotMachine(n);
        machine.makeInvisible();

        ArrayList<int[]> actions = new ArrayList<int[]>();
        int k = machine.distinctSymbols();
        if (k == 1) {
            return toArray(actions);
        }

        // FASE 1: Llevar los simbolos visibles a ser todos distintos (k == n)
        while (k < n) {
            boolean aumento = false;

            // Intentar paso a paso en cada rueda
            for (int w = 1; w <= n && !aumento; w++) {
                int kOriginal = k;
                int pasosDados = 0;

                for (int s = 1; s < n; s++) {
                    ejecutarGiro(w, 1, actions);
                    pasosDados++;
                    int kActual = machine.distinctSymbols();

                    if (kActual > kOriginal) {
                        k = kActual;
                        aumento = true;
                        break;
                    } else if (kActual < kOriginal) {
                        // Si disminuye, la rueda era unica; devolvemos inmediatamente
                        ejecutarGiro(w, -pasosDados, actions);
                        break;
                    }
                }
            }

            // Si ningun paso directo aumento, hacer escaneo completo de la rueda duplicada
            if (!aumento) {
                for (int w = 1; w <= n && !aumento; w++) {
                    int kOriginal = k;
                    int mejorPaso = 0;
                    int kMax = kOriginal;

                    for (int s = 1; s < n; s++) {
                        ejecutarGiro(w, 1, actions);
                        int kActual = machine.distinctSymbols();
                        if (kActual > kMax) {
                            kMax = kActual;
                            mejorPaso = s;
                        }
                    }
                    // Regresar a la posicion base (dar 1 paso mas completa n pasos)
                    ejecutarGiro(w, 1, actions);

                    if (kMax > kOriginal) {
                        ejecutarGiro(w, mejorPaso, actions);
                        k = kMax;
                        aumento = true;
                        break;
                    }
                }
            }
        }

        // FASE 2: Encontrar el desfase d[i] de cada rueda i (2..n) respecto a la rueda 1
        int[] d = new int[n + 1];
        for (int i = 2; i <= n; i++) {
            int pasoEncontrado = -1;
            ArrayList<Integer> candidatos = new ArrayList<Integer>();

            for (int s = 1; s < n; s++) {
                ejecutarGiro(i, 1, actions);
                ejecutarGiro(1, 1, actions);
                int kA = machine.distinctSymbols();
                ejecutarGiro(1, -1, actions);

                if (kA >= n - 1) {
                    candidatos.add(s);
                    if (kA == n) {
                        pasoEncontrado = s;
                        ejecutarGiro(i, -s, actions);
                        break;
                    }
                }
            }

            if (pasoEncontrado == -1) {
                ejecutarGiro(i, 1, actions); // vuelve a su origen (n pasos)

                if (candidatos.size() == 1) {
                    pasoEncontrado = candidatos.get(0);
                } else if (candidatos.size() >= 2) {
                    // Desempate con giro en direccion opuesta
                    for (int cand : candidatos) {
                        ejecutarGiro(i, cand, actions);
                        ejecutarGiro(1, -1, actions);
                        int kB = machine.distinctSymbols();
                        ejecutarGiro(1, 1, actions);
                        ejecutarGiro(i, -cand, actions);

                        if (kB >= n - 1) {
                            pasoEncontrado = cand;
                            break;
                        }
                    }
                }
            }
            d[i] = pasoEncontrado;
        }

        // FASE 3: Girar las ruedas para alcanzar el jackpot
        for (int i = 2; i <= n; i++) {
            if (d[i] > 0) {
                ejecutarGiro(i, d[i], actions);
            }
        }

        return toArray(actions);
    }

    /**
     * Simula las acciones necesarias para ganar con una maquina visible.
     * Muestra la animacion en pantalla hasta alcanzar el jackpot.
     * 
     * @param n numero de ruedas y simbolos.
     */
    public void simulate(int n) {
        machine = new SlotMachine(n);
        machine.makeVisible();

        int k = machine.distinctSymbols();
        if (k == 1) {
            return;
        }

        // FASE 1: Distintos
        while (k < n) {
            boolean aumento = false;
            for (int w = 1; w <= n && !aumento; w++) {
                int kOriginal = k;
                int pasosDados = 0;
                for (int s = 1; s < n; s++) {
                    machine.spin(w, 1);
                    pasosDados++;
                    int kActual = machine.distinctSymbols();
                    if (kActual > kOriginal) {
                        k = kActual;
                        aumento = true;
                        break;
                    } else if (kActual < kOriginal) {
                        machine.spin(w, -pasosDados);
                        break;
                    }
                }
            }
            if (!aumento) {
                for (int w = 1; w <= n && !aumento; w++) {
                    int kOriginal = k;
                    int mejorPaso = 0;
                    int kMax = kOriginal;
                    for (int s = 1; s < n; s++) {
                        machine.spin(w, 1);
                        int kActual = machine.distinctSymbols();
                        if (kActual > kMax) {
                            kMax = kActual;
                            mejorPaso = s;
                        }
                    }
                    machine.spin(w, 1);
                    if (kMax > kOriginal) {
                        machine.spin(w, mejorPaso);
                        k = kMax;
                        aumento = true;
                        break;
                    }
                }
            }
        }

        // FASE 2: Desfases
        int[] d = new int[n + 1];
        for (int i = 2; i <= n; i++) {
            int pasoEncontrado = -1;
            ArrayList<Integer> candidatos = new ArrayList<Integer>();

            for (int s = 1; s < n; s++) {
                machine.spin(i, 1);
                machine.spin(1, 1);
                int kA = machine.distinctSymbols();
                machine.spin(1, -1);

                if (kA >= n - 1) {
                    candidatos.add(s);
                    if (kA == n) {
                        pasoEncontrado = s;
                        machine.spin(i, -s);
                        break;
                    }
                }
            }

            if (pasoEncontrado == -1) {
                machine.spin(i, 1);

                if (candidatos.size() == 1) {
                    pasoEncontrado = candidatos.get(0);
                } else if (candidatos.size() >= 2) {
                    for (int cand : candidatos) {
                        machine.spin(i, cand);
                        machine.spin(1, -1);
                        int kB = machine.distinctSymbols();
                        machine.spin(1, 1);
                        machine.spin(i, -cand);

                        if (kB >= n - 1) {
                            pasoEncontrado = cand;
                            break;
                        }
                    }
                }
            }
            d[i] = pasoEncontrado;
        }

        // FASE 3: Alinear y ganar
        for (int i = 2; i <= n; i++) {
            if (d[i] > 0) {
                machine.spin(i, d[i]);
            }
        }
    }

    /**
     * Retorna la maquina utilizada en la ultima operacion.
     * 
     * @return objeto SlotMachine.
     */
    public SlotMachine getMachine() {
        return machine;
    }

    private void ejecutarGiro(int wheel, int steps, ArrayList<int[]> actions) {
        machine.spin(wheel, steps);
        actions.add(new int[]{wheel, steps});
    }

    private int[][] toArray(ArrayList<int[]> list) {
        int[][] res = new int[list.size()][2];
        for (int i = 0; i < list.size(); i++) {
            res[i] = list.get(i);
        }
        return res;
    }
}
