import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Pruebas de unidad para el Ciclo 4 de SlotMachine (tipos de ruedas y simbolos).
 * Todas se ejecutan en modo invisible.
 * 
 * @author Reyes y Barragan
 * @version 2026-2
 */
public class SlotMachineC4Test {

    // ---------------------------------------------------------------
    // Creacion de ruedas y simbolos por tipo
    // ---------------------------------------------------------------

    /**
     * Que deberia hacer: crear cada rueda con el tipo pedido, en la posicion pedida.
     * Que no deberia hacer: cambiar el tipo ni el orden de las ruedas.
     */
    @Test
    public void accordingBBRLShouldAddWheelsOfDifferentTypes() {
        SlotMachine slotMachine = new SlotMachine();
        slotMachine.addSymbol(1, "red");

        slotMachine.addWheel("normal", 1);
        slotMachine.addWheel("rebel", 2);
        slotMachine.addWheel("lefty", 3);
        slotMachine.addWheel("reverse", 4);

        assertArrayEquals(new String[]{"normal", "rebel", "lefty", "reverse"},
                          slotMachine.wheelTypes());
        assertTrue(slotMachine.ok());
    }

    /**
     * Que deberia hacer: seguir creando una rueda normal con addWheel(pos).
     * Que no deberia hacer: crear un tipo distinto al normal.
     */
    @Test
    public void accordingBBRLShouldAddNormalWheelByDefault() {
        SlotMachine slotMachine = new SlotMachine();
        slotMachine.addWheel(1);

        assertArrayEquals(new String[]{"normal"}, slotMachine.wheelTypes());
    }

    /**
     * Que deberia hacer: rechazar un tipo de rueda que no existe.
     * Que no deberia hacer: agregar la rueda ni terminar con ok() verdadero.
     */
    @Test
    public void accordingBBRLShouldNotAddWheelOfUnknownType() {
        SlotMachine slotMachine = new SlotMachine();
        slotMachine.addWheel("gigante", 1);

        assertFalse(slotMachine.ok());
        assertEquals(0, slotMachine.wheelTypes().length);
    }

    /**
     * Que deberia hacer: guardar el tipo de cada simbolo en el orden de los simbolos.
     * Que no deberia hacer: perder el tipo cuando se agrega otro simbolo antes.
     */
    @Test
    public void accordingBBRLShouldAddSymbolsOfDifferentTypes() {
        SlotMachine slotMachine = new SlotMachine();

        slotMachine.addSymbol("normal", 1, "red");
        slotMachine.addSymbol("ephemeral", 2, "blue");
        slotMachine.addSymbol("shy", 3, "green");

        assertArrayEquals(new String[]{"red", "blue", "green"}, slotMachine.symbols());
        assertArrayEquals(new String[]{"normal", "ephemeral", "shy"}, slotMachine.symbolTypes());
        assertTrue(slotMachine.ok());
    }

    /**
     * Que deberia hacer: rechazar un tipo de simbolo que no existe.
     * Que no deberia hacer: agregar el simbolo.
     */
    @Test
    public void accordingBBRLShouldNotAddSymbolOfUnknownType() {
        SlotMachine slotMachine = new SlotMachine();
        slotMachine.addSymbol("invisible", 1, "red");

        assertFalse(slotMachine.ok());
        assertEquals(0, slotMachine.symbols().length);
    }

    /**
     * Que deberia hacer: eliminar el simbolo y tambien su tipo.
     * Que no deberia hacer: dejar los tipos desordenados respecto a los simbolos.
     */
    @Test
    public void accordingBBRLShouldKeepSymbolTypesAfterDeletingASymbol() {
        SlotMachine slotMachine = new SlotMachine();
        slotMachine.addSymbol("normal", 1, "red");
        slotMachine.addSymbol("ephemeral", 2, "blue");
        slotMachine.addSymbol("shy", 3, "green");

        slotMachine.delSymbol("blue");

        assertArrayEquals(new String[]{"red", "green"}, slotMachine.symbols());
        assertArrayEquals(new String[]{"normal", "shy"}, slotMachine.symbolTypes());
    }

    // ---------------------------------------------------------------
    // Rueda lefty
    // ---------------------------------------------------------------

    /**
     * Que deberia hacer: copiar el simbolo de la rueda de la izquierda al girar.
     * Que no deberia hacer: mostrar un simbolo distinto al de su vecina.
     */
    @Test
    public void accordingBBRLShouldLeftyWheelCopyTheWheelOnItsLeft() {
        SlotMachine slotMachine = new SlotMachine();
        slotMachine.addSymbol(1, "red");
        slotMachine.addSymbol(2, "blue");
        slotMachine.addSymbol(3, "green");
        slotMachine.addWheel("normal", 1);
        slotMachine.addWheel("lefty", 2);
        slotMachine.placeSymbol(1, "red");
        slotMachine.placeSymbol(2, "blue");

        slotMachine.spin(2, 1);

        assertArrayEquals(new String[]{"red", "red"}, slotMachine.configuration());
    }

    /**
     * Que deberia hacer: copiar el nuevo estado cuando la rueda izquierda tambien gira.
     * Que no deberia hacer: quedarse con el simbolo anterior de su vecina.
     */
    @Test
    public void accordingBBRLShouldLeftyWheelFollowTheLeftWheelWhenAllSpin() {
        SlotMachine slotMachine = new SlotMachine();
        slotMachine.addSymbol(1, "red");
        slotMachine.addSymbol(2, "blue");
        slotMachine.addSymbol(3, "green");
        slotMachine.addWheel("normal", 1);
        slotMachine.addWheel("lefty", 2);
        slotMachine.placeSymbol(1, "red");

        slotMachine.spin();

        assertArrayEquals(new String[]{"blue", "blue"}, slotMachine.configuration());
    }

    /**
     * Que deberia hacer: girar como una rueda normal si no tiene rueda a su izquierda.
     * Que no deberia hacer: quedarse quieta ni fallar.
     */
    @Test
    public void accordingBBRLShouldLeftyWheelSpinNormallyWithoutLeftWheel() {
        SlotMachine slotMachine = new SlotMachine();
        slotMachine.addSymbol(1, "red");
        slotMachine.addSymbol(2, "blue");
        slotMachine.addWheel("lefty", 1);
        slotMachine.placeSymbol(1, "red");

        slotMachine.spin(1, 1);

        assertArrayEquals(new String[]{"blue"}, slotMachine.configuration());
    }

    /**
     * Que deberia hacer: actualizar a su vecina izquierda cuando se intercambian ruedas.
     * Que no deberia hacer: seguir copiando a la rueda que ya no esta a su izquierda.
     */
    @Test
    public void accordingBBRLShouldLeftyWheelCopyItsNewNeighborAfterSwap() {
        SlotMachine slotMachine = new SlotMachine();
        slotMachine.addSymbol(1, "red");
        slotMachine.addSymbol(2, "blue");
        slotMachine.addSymbol(3, "green");
        slotMachine.addWheel("normal", 1);
        slotMachine.addWheel("lefty", 2);
        slotMachine.addWheel("normal", 3);
        slotMachine.spin(new String[]{"red", "blue", "green"});

        slotMachine.swap(2, 3);   // ahora: normal(red), normal(green), lefty(blue)
        slotMachine.spin(3, 1);   // la lefty copia a la que tiene a la izquierda

        assertArrayEquals(new String[]{"red", "green", "green"}, slotMachine.configuration());
    }

    // ---------------------------------------------------------------
    // Rueda rebel
    // ---------------------------------------------------------------

    /**
     * Que deberia hacer: negarse a ser bloqueada y seguir girando.
     * Que no deberia hacer: quedar bloqueada.
     */
    @Test
    public void accordingBBRLShouldRebelWheelNotBeLocked() {
        SlotMachine slotMachine = new SlotMachine();
        slotMachine.addSymbol(1, "red");
        slotMachine.addSymbol(2, "blue");
        slotMachine.addWheel("rebel", 1);
        slotMachine.placeSymbol(1, "red");

        slotMachine.lock(1);
        assertFalse(slotMachine.ok());

        slotMachine.spin(1, 1);
        assertArrayEquals(new String[]{"blue"}, slotMachine.configuration());
    }

    /**
     * Que deberia hacer: negarse a ser eliminada.
     * Que no deberia hacer: desaparecer de la maquina.
     */
    @Test
    public void accordingBBRLShouldRebelWheelNotBeDeleted() {
        SlotMachine slotMachine = new SlotMachine();
        slotMachine.addSymbol(1, "red");
        slotMachine.addWheel("rebel", 1);

        slotMachine.delWheel(1);

        assertFalse(slotMachine.ok());
        assertArrayEquals(new String[]{"rebel"}, slotMachine.wheelTypes());
    }

    /**
     * Que deberia hacer: negarse a ser intercambiada, sin importar si es la primera o la segunda.
     * Que no deberia hacer: cambiar el orden de las ruedas.
     */
    @Test
    public void accordingBBRLShouldRebelWheelNotBeSwapped() {
        SlotMachine slotMachine = new SlotMachine();
        slotMachine.addSymbol(1, "red");
        slotMachine.addWheel("rebel", 1);
        slotMachine.addWheel("normal", 2);

        slotMachine.swap(1, 2);
        assertFalse(slotMachine.ok());
        assertArrayEquals(new String[]{"rebel", "normal"}, slotMachine.wheelTypes());

        slotMachine.swap(2, 1);
        assertFalse(slotMachine.ok());
        assertArrayEquals(new String[]{"rebel", "normal"}, slotMachine.wheelTypes());
    }

    /**
     * Que deberia hacer: permitir bloquear, intercambiar y eliminar ruedas normales.
     * Que no deberia hacer: aplicarles las restricciones de la rebelde.
     */
    @Test
    public void accordingBBRLShouldNormalWheelAllowLockSwapAndDelete() {
        SlotMachine slotMachine = new SlotMachine();
        slotMachine.addSymbol(1, "red");
        slotMachine.addWheel("normal", 1);
        slotMachine.addWheel("normal", 2);

        slotMachine.lock(1);
        assertTrue(slotMachine.ok());
        slotMachine.swap(1, 2);
        assertTrue(slotMachine.ok());
        slotMachine.delWheel(1);
        assertTrue(slotMachine.ok());
        assertEquals(1, slotMachine.wheelTypes().length);
    }

    // ---------------------------------------------------------------
    // Rueda reverse (tipo propuesto por el equipo)
    // ---------------------------------------------------------------

    /**
     * Que deberia hacer: girar al reves (un paso adelante la hace retroceder).
     * Que no deberia hacer: avanzar como una rueda normal.
     */
    @Test
    public void accordingBBRLShouldReverseWheelSpinBackwards() {
        SlotMachine slotMachine = new SlotMachine();
        slotMachine.addSymbol(1, "red");
        slotMachine.addSymbol(2, "blue");
        slotMachine.addSymbol(3, "green");
        slotMachine.addWheel("reverse", 1);
        slotMachine.placeSymbol(1, "red");

        slotMachine.spin(1, 1);

        assertArrayEquals(new String[]{"green"}, slotMachine.configuration());
    }

    // ---------------------------------------------------------------
    // Simbolos ephemeral y shy (se prueban las clases directamente)
    // ---------------------------------------------------------------

    /**
     * Que deberia hacer: achicarse en cada giro de la rueda.
     * Que no deberia hacer: conservar el tamano inicial.
     */
    @Test
    public void accordingBBRLShouldEphemeralSymbolShrinkOnEachSpin() {
        EphemeralSymbol symbol = new EphemeralSymbol("red");
        int initial = symbol.getSize();

        symbol.onSpin();
        int afterOne = symbol.getSize();
        symbol.onSpin();
        int afterTwo = symbol.getSize();

        assertTrue(afterOne < initial);
        assertTrue(afterTwo < afterOne);
    }

    /**
     * Que deberia hacer: quedar como un punto (tamano minimo) y no achicarse mas.
     * Que no deberia hacer: llegar a tamano cero o negativo.
     */
    @Test
    public void accordingBBRLShouldEphemeralSymbolStopShrinkingAsADot() {
        EphemeralSymbol symbol = new EphemeralSymbol("red");

        for (int i = 0; i < 100; i++) {
            symbol.onSpin();
        }
        int dot = symbol.getSize();
        symbol.onSpin();

        assertEquals(dot, symbol.getSize());
        assertTrue(dot > 0);
        assertTrue(dot <= 2);
    }

    /**
     * Que deberia hacer: alternar visible/escondido cada vez que es seleccionado.
     * Que no deberia hacer: quedarse siempre en el mismo estado.
     */
    @Test
    public void accordingBBRLShouldShySymbolToggleWhenSelected() {
        ShySymbol symbol = new ShySymbol("red");
        assertTrue(symbol.isShown());

        symbol.onSelected();
        assertFalse(symbol.isShown());

        symbol.onSelected();
        assertTrue(symbol.isShown());
    }

    /**
     * Que deberia hacer: alternar solo cuando la rueda lo selecciona al girar.
     * Que no deberia hacer: alternar cuando no se gira la rueda o cuando se selecciona otro simbolo.
     */
    @Test
    public void accordingBBRLShouldShySymbolToggleOnlyWhenWheelSelectsIt() {
        Wheel wheel = new Wheel();
        wheel.addSymbol(1, new NormalSymbol("red"));
        ShySymbol shy = new ShySymbol("blue");
        wheel.addSymbol(2, shy);

        assertTrue(shy.isShown());      // todavia no ha sido seleccionado

        wheel.spin();                   // ahora se selecciona "blue"
        assertFalse(shy.isShown());

        wheel.spin();                   // se selecciona "red": el timido no cambia
        assertFalse(shy.isShown());

        wheel.spin();                   // se vuelve a seleccionar "blue"
        assertTrue(shy.isShown());
    }

    /**
     * Que deberia hacer: seguir contando como simbolo de su color aunque este escondido.
     * Que no deberia hacer: romper la configuracion ni el jackpot de la maquina.
     */
    @Test
    public void accordingBBRLShouldShySymbolKeepItsColorInConfiguration() {
        SlotMachine slotMachine = new SlotMachine();
        slotMachine.addSymbol("normal", 1, "red");
        slotMachine.addSymbol("shy", 2, "blue");
        slotMachine.addWheel(1);
        slotMachine.addWheel(2);

        slotMachine.spin(new String[]{"blue", "blue"});

        assertArrayEquals(new String[]{"blue", "blue"}, slotMachine.configuration());
        assertTrue(slotMachine.isJackpot());
    }

    // ---------------------------------------------------------------
    // Combinacion de tipos
    // ---------------------------------------------------------------

    /**
     * Que deberia hacer: poder agregar una rueda despues de tener simbolos de varios tipos,
     * y que la nueva rueda tenga todos los simbolos.
     * Que no deberia hacer: perder simbolos al crear ruedas nuevas.
     */
    @Test
    public void accordingBBRLShouldNewWheelsReceiveSymbolsOfAllTypes() {
        SlotMachine slotMachine = new SlotMachine();
        slotMachine.addSymbol("normal", 1, "red");
        slotMachine.addSymbol("ephemeral", 2, "blue");
        slotMachine.addSymbol("shy", 3, "green");

        slotMachine.addWheel("lefty", 1);
        slotMachine.placeSymbol(1, "green");
        slotMachine.placeSymbol(1, "blue");

        assertArrayEquals(new String[]{"blue"}, slotMachine.configuration());
        assertTrue(slotMachine.ok());
    }

    /**
     * Que deberia hacer: seguir encontrando la solucion de la maraton con ruedas normales.
     * Que no deberia hacer: dejar de funcionar por los cambios del ciclo 4.
     */
    @Test
    public void accordingBBRLShouldStillSolveTheContestWithNewTypes() {
        SlotMachineContest contest = new SlotMachineContest();
        contest.solve(4);

        assertEquals(1, contest.getMachine().distinctSymbols());
    }
}
