import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Casos de pruebas de unidad del proyecto: SlotMachineContestTest.
 * Todas las pruebas se ejecutan en modo invisible.
 * 
 * Tabla de diseño de pruebas:
 * 1. shouldCreateSlotMachineWithNWheelsAndSymbols()
 *    - ¿Que deberia hacer?: Crear una maquina con n ruedas y n simbolos con configuracion de tamano n y k > 1.
 *    - ¿Que no deberia hacer?: Dejar la maquina vacia o en estado de jackpot inicial.
 * 
 * 2. shouldSolveSuccessfullyForN3()
 *    - ¿Que deberia hacer?: Encontrar la secuencia de giros que lleva a jackpot (distinctSymbols == 1).
 *    - ¿Que no deberia hacer?: Terminar con mas de un simbolo distinto visible.
 * 
 * 3. shouldSolveSuccessfullyForN4()
 *    - ¿Que deberia hacer?: Resolver exitosamente una maquina de tamano 4.
 *    - ¿Que no deberia hacer?: Fallar o sobrepasar el limite de acciones.
 * 
 * 4. shouldSolveSuccessfullyForN5()
 *    - ¿Que deberia hacer?: Resolver exitosamente una maquina de tamano 5.
 *    - ¿Que no deberia hacer?: Fallar o dejar ruedas sin alinear.
 * 
 * 5. shouldSolveWithin10000Actions()
 *    - ¿Que deberia hacer?: Resolver el reto en menos de 10.000 acciones.
 *    - ¿Que no deberia hacer?: Exceder el limite de 10.000 acciones establecido por la maraton.
 * 
 * @author Reyes y Barragan
 * @version 2026-2
 */
public class SlotMachineContestTest {

    @Test
    public void shouldCreateSlotMachineWithNWheelsAndSymbols() {
        int n = 4;
        SlotMachine machine = new SlotMachine(n);

        String[] config = machine.configuration();
        assertEquals(n, config.length);
        assertEquals(n, machine.symbols().length);

        // Se garantiza que inicialmente no empiece en jackpot
        assertTrue(machine.distinctSymbols() > 1);
        assertFalse(machine.isJackpot());
    }

    @Test
    public void shouldSolveSuccessfullyForN3() {
        int n = 3;
        SlotMachineContest contest = new SlotMachineContest();
        int[][] actions = contest.solve(n);

        assertNotNull(actions);
        assertTrue(actions.length > 0);
        assertTrue(actions.length <= 10000);

        SlotMachine machine = contest.getMachine();
        assertNotNull(machine);
        assertEquals(1, machine.distinctSymbols());
        assertTrue(machine.isJackpot());
    }

    @Test
    public void shouldSolveSuccessfullyForN4() {
        int n = 4;
        SlotMachineContest contest = new SlotMachineContest();
        int[][] actions = contest.solve(n);

        assertNotNull(actions);
        assertTrue(actions.length > 0);
        assertTrue(actions.length <= 10000);

        SlotMachine machine = contest.getMachine();
        assertEquals(1, machine.distinctSymbols());
        assertTrue(machine.isJackpot());
    }

    @Test
    public void shouldSolveSuccessfullyForN5() {
        int n = 5;
        SlotMachineContest contest = new SlotMachineContest();
        int[][] actions = contest.solve(n);

        assertNotNull(actions);
        assertTrue(actions.length > 0);
        assertTrue(actions.length <= 10000);

        SlotMachine machine = contest.getMachine();
        assertEquals(1, machine.distinctSymbols());
        assertTrue(machine.isJackpot());
    }

    @Test
    public void shouldSolveWithin10000Actions() {
        int n = 8;
        SlotMachineContest contest = new SlotMachineContest();
        int[][] actions = contest.solve(n);

        assertNotNull(actions);
        assertTrue("El numero de acciones debe ser <= 10000 pero fue " + actions.length, actions.length <= 10000);

        SlotMachine machine = contest.getMachine();
        assertEquals(1, machine.distinctSymbols());
    }
}
