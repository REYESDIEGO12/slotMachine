import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Pruebas de unidad para el Ciclo 2 de SlotMachine.
 * Ejecutan en modo invisible.
 * 
 * @author Reyes y Barragan
 * @version 2026-2
 */
public class SlotMachineC2Test {

    /**
     * Verifica que al intercambiar dos ruedas se intercambie su configuracion.
     * Que deberia hacer: intercambiar correctamente las posiciones de dos ruedas.
     * Que no deberia hacer: dejar las ruedas en la misma posicion.
     */
    @Test
    public void accordingBBRLShouldSwapWheels() {
        SlotMachine slotMachine = new SlotMachine();

        slotMachine.addSymbol(1, "red");
        slotMachine.addSymbol(2, "blue");

        slotMachine.addWheel(1);
        slotMachine.addWheel(2);

        slotMachine.placeSymbol(1, "red");
        slotMachine.placeSymbol(2, "blue");

        String[] before = slotMachine.configuration();
        assertArrayEquals(new String[]{"red", "blue"}, before);

        slotMachine.swap(1, 2);

        String[] after = slotMachine.configuration();
        assertArrayEquals(new String[]{"blue", "red"}, after);
        assertTrue(slotMachine.ok());
    }

    /**
     * Verifica que una rueda bloqueada no pueda girar.
     * Que deberia hacer: mantener la rueda en el mismo simbolo cuando esta fijada.
     * Que no deberia hacer: cambiar el simbolo de una rueda fijada.
     */
    @Test
    public void accordingBBRLShouldNotSpinWhenLocked() {
        SlotMachine slotMachine = new SlotMachine();

        slotMachine.addSymbol(1, "red");
        slotMachine.addSymbol(2, "blue");
        slotMachine.addSymbol(3, "green");

        slotMachine.addWheel(1);
        slotMachine.placeSymbol(1, "red");

        slotMachine.lock(1);
        slotMachine.spin(1, 1);

        assertArrayEquals(new String[]{"red"}, slotMachine.configuration());
    }

    /**
     * Verifica que una rueda desbloqueada pueda girar.
     * Que deberia hacer: permitir que una rueda gire despues de ser liberada.
     * Que no deberia hacer: permanecer bloqueada despues de unlock().
     */
    @Test
    public void accordingBBRLShouldSpinWhenUnlocked() {
        SlotMachine slotMachine = new SlotMachine();

        slotMachine.addSymbol(1, "red");
        slotMachine.addSymbol(2, "blue");

        slotMachine.addWheel(1);
        slotMachine.placeSymbol(1, "red");

        slotMachine.lock(1);
        slotMachine.unlock(1);

        slotMachine.spin(1, 1);

        assertArrayEquals(new String[]{"blue"}, slotMachine.configuration());
    }

    /**
     * Verifica que una rueda avance exactamente el numero de pasos indicado.
     * Que deberia hacer: girar exactamente la cantidad de pasos indicada.
     * Que no deberia hacer: avanzar una cantidad diferente de pasos.
     */
    @Test
    public void accordingBBRLShouldSpinTheSpecifiedNumberOfSteps() {
        SlotMachine slotMachine = new SlotMachine();

        slotMachine.addSymbol(1, "red");
        slotMachine.addSymbol(2, "blue");
        slotMachine.addSymbol(3, "green");

        slotMachine.addWheel(1);
        slotMachine.placeSymbol(1, "red");

        slotMachine.spin(1, 2);

        assertArrayEquals(new String[]{"green"}, slotMachine.configuration());
    }

    /**
     * Verifica que la maquina pueda quedar en una configuracion dada.
     * Que deberia hacer: dejar las ruedas en la configuracion solicitada.
     * Que no deberia hacer: dejar una configuracion diferente a la indicada.
     */
    @Test
    public void accordingBBRLShouldSetTheSpecifiedConfiguration() {
        SlotMachine slotMachine = new SlotMachine();

        slotMachine.addSymbol(1, "red");
        slotMachine.addSymbol(2, "blue");
        slotMachine.addSymbol(3, "green");

        slotMachine.addWheel(1);
        slotMachine.addWheel(2);
        slotMachine.addWheel(3);

        String[] setSymbols = {"green", "blue", "red"};
        slotMachine.spin(setSymbols);

        assertArrayEquals(setSymbols, slotMachine.configuration());
        assertTrue(slotMachine.ok());
    }
}
