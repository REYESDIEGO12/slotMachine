import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.util.*;

/**
 * Canvas is a class to allow for simple graphical drawing on a canvas.
 * This is a modification of the general purpose Canvas, specially made for
 * the BlueJ "shapes" example.
 *
 * @author: Bruce Quig
 * @author: Michael Kolling (mik)
 * @author: Reyes y Barragan (extension colores CSS)
 *
 * @version 2026-2
 */
public class Canvas {
    // Note: The implementation of this class (specifically the handling of
    // shape identity and colors) is slightly hacky. It is done like this to
    // have a gentle introduction to the Shapes example, and not to optimize
    // performance.

    private static Canvas canvasSingleton;

    /**
     * Factory method to get the canvas singleton object.
     */
    public static Canvas getCanvas() {
        if (canvasSingleton == null) {
            canvasSingleton = new Canvas("Slot Machine Simulator", 800, 500, Color.white);
        }
        canvasSingleton.setVisible(true);
        return canvasSingleton;
    }

    //  ----- instance part -----

    private JFrame frame;
    private CanvasPane canvas;
    private Graphics2D graphic;
    private Color backgroundColour;
    private Image canvasImage;
    private java.util.List<Object> objects;
    private HashMap<Object, ShapeDescription> shapes;

    /**
     * Create a Canvas.
     * @param title    title to appear in Canvas Frame
     * @param width    the desired width for the canvas
     * @param height   the desired height for the canvas
     * @param bgColour the desired background colour of the canvas
     */
    private Canvas(String title, int width, int height, Color bgColour) {
        frame = new JFrame();
        canvas = new CanvasPane();
        frame.setContentPane(canvas);
        frame.setTitle(title);
        canvas.setPreferredSize(new Dimension(width, height));
        backgroundColour = bgColour;
        frame.pack();
        objects = new ArrayList<Object>();
        shapes = new HashMap<Object, ShapeDescription>();
    }

    /**
     * Set the canvas visibility and brings canvas to the front of screen
     * when made visible. This method can also be used to bring an already
     * visible canvas to the front of other windows.
     * @param visible boolean value representing the desired visibility of
     * the canvas (true or false) 
     */
    public void setVisible(boolean visible) {
        if (graphic == null) {
            // first time: instantiate the offscreen image and fill it with
            // the background colour
            Dimension size = canvas.getSize();
            canvasImage = canvas.createImage(size.width, size.height);
            graphic = (Graphics2D) canvasImage.getGraphics();
            graphic.setColor(backgroundColour);
            graphic.fillRect(0, 0, size.width, size.height);
            graphic.setColor(Color.black);
        }
        frame.setVisible(visible);
    }

    /**
     * Draw a given shape onto the canvas.
     * @param  referenceObject  an object to define identity for this shape
     * @param  color            the color of the shape
     * @param  shape            the shape object to be drawn on the canvas
     */
    public void draw(Object referenceObject, String color, Shape shape) {
        objects.remove(referenceObject);   // just in case it was already there
        objects.add(referenceObject);      // add at the end
        shapes.put(referenceObject, new ShapeDescription(shape, color));
        redraw();
    }

    /**
     * Erase a given shape's from the screen.
     * @param  referenceObject  the shape object to be erased 
     */
    public void erase(Object referenceObject) {
        objects.remove(referenceObject);   // just in case it was already there
        shapes.remove(referenceObject);
        redraw();
    }

    /**
     * Set the foreground colour of the Canvas.
     * Soporta los colores basicos y nombres del estandar CSS.
     * @param  colorString   the new colour for the foreground of the Canvas 
     */
    public void setForegroundColor(String colorString) {
        if (colorString == null) {
            graphic.setColor(Color.black);
            return;
        }

        String c = colorString.trim().toLowerCase();
        if (c.equals("red")) {
            graphic.setColor(Color.red);
        } else if (c.equals("black")) {
            graphic.setColor(Color.black);
        } else if (c.equals("blue")) {
            graphic.setColor(Color.blue);
        } else if (c.equals("yellow")) {
            graphic.setColor(Color.yellow);
        } else if (c.equals("green")) {
            graphic.setColor(Color.green);
        } else if (c.equals("magenta")) {
            graphic.setColor(Color.magenta);
        } else if (c.equals("white")) {
            graphic.setColor(Color.white);
        } else if (c.equals("orange")) {
            graphic.setColor(Color.orange);
        } else if (c.equals("pink")) {
            graphic.setColor(Color.pink);
        } else if (c.equals("cyan")) {
            graphic.setColor(Color.cyan);
        } else if (c.equals("gray") || c.equals("grey")) {
            graphic.setColor(Color.gray);
        } else if (c.equals("darkgray") || c.equals("darkgrey")) {
            graphic.setColor(Color.darkGray);
        } else if (c.equals("lightgray") || c.equals("lightgrey")) {
            graphic.setColor(Color.lightGray);
        } else {
            Color custom = getCustomColor(c);
            graphic.setColor(custom);
        }
    }

    /**
     * Obtiene un color extendido segun estandar CSS.
     */
    private Color getCustomColor(String name) {
        if (name.equals("purple")) return new Color(128, 0, 128);
        if (name.equals("brown")) return new Color(165, 42, 42);
        if (name.equals("lime")) return new Color(50, 205, 50);
        if (name.equals("gold")) return new Color(255, 215, 0);
        if (name.equals("navy")) return new Color(0, 0, 128);
        if (name.equals("teal")) return new Color(0, 128, 128);
        if (name.equals("maroon")) return new Color(128, 0, 0);
        if (name.equals("olive")) return new Color(128, 128, 0);
        if (name.equals("violet")) return new Color(238, 130, 238);
        if (name.equals("indigo")) return new Color(75, 0, 130);
        if (name.equals("turquoise")) return new Color(64, 224, 208);
        if (name.equals("silver")) return new Color(192, 192, 192);
        if (name.equals("coral")) return new Color(255, 127, 80);
        if (name.equals("crimson")) return new Color(220, 20, 60);
        if (name.equals("khaki")) return new Color(240, 230, 140);
        if (name.equals("plum")) return new Color(221, 160, 221);
        if (name.equals("salmon")) return new Color(250, 128, 114);
        if (name.equals("sienna")) return new Color(160, 82, 45);
        if (name.equals("tan")) return new Color(210, 180, 140);
        if (name.equals("tomato")) return new Color(255, 99, 71);
        if (name.equals("chocolate")) return new Color(210, 105, 30);
        if (name.equals("peru")) return new Color(205, 133, 63);
        if (name.equals("chartreuse")) return new Color(127, 255, 0);
        if (name.equals("wheat")) return new Color(245, 222, 179);
        if (name.equals("orchid")) return new Color(218, 112, 214);
        if (name.equals("lavender")) return new Color(230, 230, 250);
        if (name.equals("aquamarine")) return new Color(127, 255, 212);
        if (name.equals("goldenrod")) return new Color(218, 165, 32);
        if (name.equals("seagreen")) return new Color(46, 139, 87);
        if (name.equals("steelblue")) return new Color(70, 130, 180);
        if (name.equals("skyblue")) return new Color(135, 206, 235);
        // Si es otro nombre, se genera un tono distinguible
        float hue = Math.abs(name.hashCode() % 360) / 360.0f;
        return Color.getHSBColor(hue, 0.75f, 0.90f);
    }

    /**
     * Wait for a specified number of milliseconds before finishing.
     * This provides an easy way to specify a small delay which can be
     * used when producing animations.
     * @param  milliseconds  the number 
     */
    public void wait(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (Exception e) {
            // ignoring exception at the moment
        }
    }

    /**
     * Redraw ell shapes currently on the Canvas.
     */
    private void redraw() {
        erase();
        for (Iterator<Object> i = objects.iterator(); i.hasNext(); ) {
            shapes.get(i.next()).draw(graphic);
        }
        canvas.repaint();
    }

    /**
     * Erase the whole canvas. (Does not repaint.)
     */
    private void erase() {
        Color original = graphic.getColor();
        graphic.setColor(backgroundColour);
        Dimension size = canvas.getSize();
        graphic.fill(new java.awt.Rectangle(0, 0, size.width, size.height));
        graphic.setColor(original);
    }

    /************************************************************************
     * Inner class CanvasPane - the actual canvas component contained in the
     * Canvas frame.
     */
    private class CanvasPane extends JPanel {
        public void paint(Graphics g) {
            g.drawImage(canvasImage, 0, 0, null);
        }
    }

    /************************************************************************
     * Inner class ShapeDescription - represents shape and color together.
     */
    private class ShapeDescription {
        private Shape shape;
        private String colorString;

        public ShapeDescription(Shape shape, String color) {
            this.shape = shape;
            colorString = color;
        }

        public void draw(Graphics2D graphic) {
            setForegroundColor(colorString);
            graphic.draw(shape);
            graphic.fill(shape);
        }
    }
}
