/**
 * Simbolo efimero: es un TRIANGULO que en cada giro de su rueda se hace mas
 * pequeno, hasta quedar casi como un punto. Una vez llega al tamano minimo
 * ya no se achica mas.
 * 
 * @author Reyes y Barragan
 * @version 2026-2
 */
public class EphemeralSymbol extends Symbol {
    private static final int BOX = 40;          // Espacio disponible dentro de la rueda
    private static final int INITIAL_SIZE = 40; // Tamano inicial del triangulo
    private static final int STEP = 5;          // Cuanto se achica en cada giro
    private static final int MIN_SIZE = 2;      // Tamano minimo (casi un punto)

    private Triangle figure;
    private int size;
    private int boxX;     // Esquina superior izquierda del espacio disponible
    private int boxY;
    private int figureX;  // Posicion actual del vertice superior del triangulo
    private int figureY;

    /**
     * Crea un simbolo efimero con el color indicado.
     * 
     * @param color color del simbolo (estandar CSS).
     */
    public EphemeralSymbol(String color) {
        super(color);
        size = INITIAL_SIZE;
        figure = new Triangle();
        figure.changeColor(color);
        figure.changeSize(size, size);

        // Posicion por defecto de un Triangle
        figureX = 140;
        figureY = 15;
        boxX = 0;
        boxY = 0;
    }

    /**
     * Retorna el nombre del tipo.
     * 
     * @return "ephemeral".
     */
    public String getType() {
        return "ephemeral";
    }

    /**
     * Retorna el tamano actual del simbolo.
     * 
     * @return tamano en pixeles (entre MIN_SIZE e INITIAL_SIZE).
     */
    public int getSize() {
        return size;
    }

    /**
     * Hace visible el triangulo.
     */
    public void makeVisible() {
        figure.makeVisible();
    }

    /**
     * Hace invisible el triangulo.
     */
    public void makeInvisible() {
        figure.makeInvisible();
    }

    /**
     * Mueve el simbolo dentro del espacio que empieza en (x, y).
     * 
     * @param x nueva posicion horizontal.
     * @param y nueva posicion vertical.
     */
    public void moveTo(int x, int y) {
        boxX = x;
        boxY = y;
        place();
    }

    /**
     * En cada giro de la rueda el simbolo se achica hasta llegar al minimo.
     */
    public void onSpin() {
        if (size > MIN_SIZE) {
            size = Math.max(MIN_SIZE, size - STEP);
            figure.changeSize(size, size);
            place();
        }
    }

    /**
     * Ubica el triangulo en el centro del espacio disponible segun su tamano actual.
     */
    private void place() {
        int targetX = boxX + BOX / 2;
        int targetY = boxY + (BOX - size) / 2;
        figure.moveHorizontal(targetX - figureX);
        figure.moveVertical(targetY - figureY);
        figureX = targetX;
        figureY = targetY;
    }
}
