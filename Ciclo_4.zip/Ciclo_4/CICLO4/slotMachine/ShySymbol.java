/**
 * Simbolo timido: es un CUADRADO que alterna entre visible e invisible cada vez
 * que es seleccionado en la rueda. Cuando esta "escondido" la ventana de la
 * rueda se ve vacia, pero para la logica de la maquina (configuracion, jackpot)
 * sigue siendo el mismo simbolo de siempre.
 * 
 * @author Reyes y Barragan
 * @version 2026-2
 */
public class ShySymbol extends Symbol {
    private static final int SIZE = 40;

    private Rectangle figure;
    private int xPosition;
    private int yPosition;
    private boolean shown;      // Estado propio del simbolo timido (visible / escondido)
    private boolean displayed;  // Indica si la rueda le pide mostrarse

    /**
     * Crea un simbolo timido con el color indicado. Empieza en estado visible.
     * 
     * @param color color del simbolo (estandar CSS).
     */
    public ShySymbol(String color) {
        super(color);
        figure = new Rectangle();
        figure.changeColor(color);
        figure.changeSize(SIZE, SIZE);

        // Posicion por defecto de un Rectangle
        xPosition = 70;
        yPosition = 15;

        shown = true;
        displayed = false;
    }

    /**
     * Retorna el nombre del tipo.
     * 
     * @return "shy".
     */
    public String getType() {
        return "shy";
    }

    /**
     * Indica si el simbolo esta en estado visible (no escondido).
     * 
     * @return true si esta en estado visible.
     */
    public boolean isShown() {
        return shown;
    }

    /**
     * La rueda pide mostrar el simbolo; solo se dibuja si esta en estado visible.
     */
    public void makeVisible() {
        displayed = true;
        refresh();
    }

    /**
     * La rueda pide ocultar el simbolo.
     */
    public void makeInvisible() {
        displayed = false;
        refresh();
    }

    /**
     * Mueve el cuadrado a la posicion (x, y).
     * 
     * @param x nueva posicion horizontal.
     * @param y nueva posicion vertical.
     */
    public void moveTo(int x, int y) {
        figure.moveHorizontal(x - xPosition);
        figure.moveVertical(y - yPosition);
        xPosition = x;
        yPosition = y;
    }

    /**
     * Cada vez que es seleccionado alterna su estado: visible -> escondido -> visible...
     */
    public void onSelected() {
        shown = !shown;
        refresh();
    }

    /**
     * Dibuja la figura solo si la rueda lo pide Y el simbolo esta en estado visible.
     */
    private void refresh() {
        if (displayed && shown) {
            figure.makeVisible();
        } else {
            figure.makeInvisible();
        }
    }
}
