import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 * Representa una maquina tragamonedas (Slot Machine).
 * Permite gestionar ruedas, simbolos de colores CSS, girar ruedas y verificar estados ganadores.
 * 
 * @author Reyes y Barragan
 * @version 2026-2
 */
public class SlotMachine {
    private ArrayList<Wheel> wheels;
    private ArrayList<String> symbols;
    private ArrayList<String> symbolTypes;
    private Rectangle machine;
    private boolean visible;
    private boolean successful;

    // Tipos de rueda y de simbolo disponibles
    private static final String[] WHEEL_TYPES = {"normal", "lefty", "rebel", "reverse"};
    private static final String[] SYMBOL_TYPES = {"normal", "ephemeral", "shy"};

    // Paleta de colores CSS estandar para inicializar simbolos distintos
    private static final String[] CSS_COLORS = {
        "red", "blue", "green", "yellow", "magenta", "orange", "cyan", "pink",
        "purple", "brown", "lime", "gold", "navy", "teal", "maroon", "olive",
        "violet", "indigo", "turquoise", "silver", "gray", "black", "white",
        "coral", "crimson", "khaki", "plum", "salmon", "sienna", "tan",
        "tomato", "chocolate", "peru", "chartreuse", "wheat", "orchid", "lavender",
        "aquamarine", "goldenrod", "seagreen", "steelblue", "skyblue", "darkgreen",
        "forestgreen", "midnightblue", "darkorange", "firebrick", "hotpink", "deeppink", "darkviolet"
    };

    /**
     * Crea una maquina tragamonedas vacia e invisible.
     */
    public SlotMachine() {
        wheels = new ArrayList<Wheel>();
        symbols = new ArrayList<String>();
        symbolTypes = new ArrayList<String>();

        machine = new Rectangle();
        machine.changeColor("magenta");
        machine.changeSize(180, 270);
        machine.moveHorizontal(-55);
        machine.moveVertical(35);

        visible = false;
        successful = true;
    }

    /**
     * Crea una maquina tragamonedas con n ruedas y n simbolos distintos,
     * inicializada aleatoriamente en un estado no ganador.
     * 
     * @param n numero de ruedas y simbolos (3 <= n <= 50).
     */
    public SlotMachine(int n) {
        this();

        if (n < 1) {
            fail("El numero de ruedas y simbolos debe ser mayor a 0.");
            return;
        }

        // 1. Agregar n simbolos con colores CSS distintos
        for (int i = 0; i < n; i++) {
            String colorName = getColorForIndex(i);
            addSymbol(i + 1, colorName);
        }

        // 2. Agregar n ruedas (cada rueda recibe los n simbolos en el mismo orden)
        for (int i = 0; i < n; i++) {
            addWheel(i + 1);
        }

        // 3. Inicializar aleatoriamente cada rueda
        for (int i = 0; i < wheels.size(); i++) {
            int randomSteps = (int) (Math.random() * n);
            wheels.get(i).spin(randomSteps);
        }

        // Garantizar que no comience en jackpot si n > 1
        if (n > 1 && isJackpotConfiguration()) {
            wheels.get(0).spin(1);
        }

        updateAppearance();
        successful = true;
    }

    /**
     * Adiciona una rueda normal en la posicion indicada.
     * 
     * @param pos posicion de la rueda (1-based).
     */
    public void addWheel(int pos) {
        addWheel("normal", pos);
    }

    /**
     * Adiciona una rueda de un tipo dado en la posicion indicada.
     * Tipos validos: "normal", "lefty", "rebel" y "reverse".
     * 
     * @param type tipo de la rueda.
     * @param pos posicion de la rueda (1-based).
     */
    public void addWheel(String type, int pos) {
        type = normalizeType(type);
        if (!contains(WHEEL_TYPES, type)) {
            fail("El tipo de rueda no existe.");
            return;
        }

        pos = normalizePosition(pos, wheels.size() + 1);

        Wheel wheel = createWheel(type);
        for (int i = 0; i < symbols.size(); i++) {
            wheel.addSymbol(i + 1, createSymbol(symbolTypes.get(i), symbols.get(i)));
        }

        wheels.add(pos - 1, wheel);
        repositionWheels();
        wheel.setVisible(visible);
        updateAppearance();

        successful = true;
    }

    /**
     * Elimina una rueda de la posicion indicada.
     * 
     * @param pos posicion de la rueda (1-based).
     */
    public void delWheel(int pos) {
        if (wheels.isEmpty()) {
            fail("No hay ruedas para eliminar.");
            return;
        }

        if (pos < 1 || pos > wheels.size()) {
            fail("La posicion de la rueda no es valida.");
            return;
        }

        if (!wheels.get(pos - 1).canBeDeleted()) {
            fail("Una rueda " + wheels.get(pos - 1).getType() + " no se deja eliminar.");
            return;
        }

        wheels.get(pos - 1).setVisible(false);
        wheels.remove(pos - 1);

        repositionWheels();
        updateAppearance();

        successful = true;
    }

    /**
     * Intercambia dos ruedas de posicion.
     * 
     * @param wheel1 posicion de la primera rueda.
     * @param wheel2 posicion de la segunda rueda.
     */
    public void swap(int wheel1, int wheel2) {
        if (wheels.isEmpty()) {
            fail("No hay ruedas para intercambiar.");
            return;
        }

        if (wheel1 < 1 || wheel1 > wheels.size() || wheel2 < 1 || wheel2 > wheels.size()) {
            fail("La posicion de una rueda no es valida.");
            return;
        }

        Wheel first = wheels.get(wheel1 - 1);
        Wheel second = wheels.get(wheel2 - 1);

        if (!first.canBeSwapped() || !second.canBeSwapped()) {
            fail("Una rueda rebelde no se deja intercambiar.");
            return;
        }

        wheels.set(wheel1 - 1, second);
        wheels.set(wheel2 - 1, first);

        repositionWheels();
        updateAppearance();

        successful = true;
    }

    /**
     * Fija una rueda para impedir que gire.
     * 
     * @param wheel posicion de la rueda.
     */
    public void lock(int wheel) {
        if (wheels.isEmpty()) {
            fail("No hay ruedas para fijar.");
            return;
        }

        if (wheel < 1 || wheel > wheels.size()) {
            fail("La posicion de la rueda no es valida.");
            return;
        }

        if (!wheels.get(wheel - 1).canBeLocked()) {
            fail("Una rueda " + wheels.get(wheel - 1).getType() + " no se deja bloquear.");
            return;
        }

        wheels.get(wheel - 1).lock();
        successful = true;
    }

    /**
     * Suelta una rueda para permitir que vuelva a girar.
     * 
     * @param wheel posicion de la rueda.
     */
    public void unlock(int wheel) {
        if (wheels.isEmpty()) {
            fail("No hay ruedas para soltar.");
            return;
        }

        if (wheel < 1 || wheel > wheels.size()) {
            fail("La posicion de la rueda no es valida.");
            return;
        }

        wheels.get(wheel - 1).unlock();
        successful = true;
    }

    /**
     * Adiciona un simbolo normal a la maquina.
     * 
     * @param pos posicion del simbolo (1-based).
     * @param color color CSS del simbolo.
     */
    public void addSymbol(int pos, String color) {
        addSymbol("normal", pos, color);
    }

    /**
     * Adiciona un simbolo de un tipo dado a la maquina.
     * Tipos validos: "normal", "ephemeral" y "shy".
     * 
     * @param type tipo del simbolo.
     * @param pos posicion del simbolo (1-based).
     * @param color color CSS del simbolo.
     */
    public void addSymbol(String type, int pos, String color) {
        type = normalizeType(type);
        if (!contains(SYMBOL_TYPES, type)) {
            fail("El tipo de simbolo no existe.");
            return;
        }

        if (color == null || color.trim().isEmpty()) {
            fail("El color del simbolo no es valido.");
            return;
        }

        color = color.trim().toLowerCase();
        if (symbols.contains(color)) {
            fail("El simbolo ya existe.");
            return;
        }

        pos = normalizePosition(pos, symbols.size() + 1);
        symbols.add(pos - 1, color);
        symbolTypes.add(pos - 1, type);

        for (Wheel wheel : wheels) {
            wheel.addSymbol(pos, createSymbol(type, color));
        }

        updateAppearance();
        successful = true;
    }

    /**
     * Elimina un simbolo de la maquina segun su color.
     * 
     * @param symbol color del simbolo a eliminar.
     */
    public void delSymbol(String symbol) {
        if (symbol == null || !symbols.contains(symbol.toLowerCase().trim())) {
            fail("El simbolo no existe.");
            return;
        }

        symbol = symbol.toLowerCase().trim();
        int index = symbols.indexOf(symbol);
        symbols.remove(index);
        symbolTypes.remove(index);

        for (Wheel wheel : wheels) {
            wheel.delSymbol(symbol);
        }

        updateAppearance();
        successful = true;
    }

    /**
     * Coloca un simbolo como visible en una rueda.
     * 
     * @param wheel posicion de la rueda.
     * @param symbol color del simbolo a mostrar.
     */
    public void placeSymbol(int wheel, String symbol) {
        if (wheels.isEmpty()) {
            fail("No hay ruedas en la maquina.");
            return;
        }

        if (wheel < 1 || wheel > wheels.size()) {
            fail("La posicion de la rueda no es valida.");
            return;
        }

        if (symbol == null || !symbols.contains(symbol.toLowerCase().trim())) {
            fail("El simbolo no existe.");
            return;
        }

        if (!wheels.get(wheel - 1).placeSymbol(symbol)) {
            fail("El simbolo no existe en la rueda.");
            return;
        }

        updateAppearance();
        successful = true;
    }

    /**
     * Gira una rueda una posicion.
     * 
     * @param wheel posicion de la rueda.
     */
    public void spin(int wheel) {
        if (wheels.isEmpty()) {
            fail("No hay ruedas en la maquina.");
            return;
        }

        if (wheel < 1 || wheel > wheels.size()) {
            fail("La posicion de la rueda no es valida.");
            return;
        }

        wheels.get(wheel - 1).spin();
        updateAppearance();
        successful = true;
    }

    /**
     * Gira todas las ruedas una posicion.
     */
    public void spin() {
        if (wheels.isEmpty()) {
            fail("No hay ruedas en la maquina.");
            return;
        }

        for (Wheel wheel : wheels) {
            wheel.spin();
        }

        updateAppearance();
        successful = true;
    }

    /**
     * Gira una rueda un numero determinado de pasos.
     * Si la maquina esta visible, el movimiento se visualiza paso a paso.
     * 
     * @param wheel posicion de la rueda.
     * @param steps cantidad de pasos a girar.
     */
    public void spin(int wheel, int steps) {
        if (wheels.isEmpty()) {
            fail("No hay ruedas en la maquina.");
            return;
        }

        if (wheel < 1 || wheel > wheels.size()) {
            fail("La posicion de la rueda no es valida.");
            return;
        }

        Wheel target = wheels.get(wheel - 1);
        if (steps == 0) {
            successful = true;
            return;
        }

        if (visible) {
            int count = Math.abs(steps);
            boolean forward = steps > 0;
            for (int i = 0; i < count; i++) {
                if (forward) {
                    target.spin();
                } else {
                    target.spinBack();
                }
                updateAppearance();
                // Animacion visual educativa usando Canvas.wait
                Canvas.getCanvas().wait(200);
            }
        } else {
            target.spin(steps);
            updateAppearance();
        }

        successful = true;
    }

    /**
     * Deja la maquina en una configuracion determinada.
     * 
     * @param setSymbols colores visibles requeridos para cada rueda.
     */
    public void spin(String[] setSymbols) {
        if (setSymbols == null) {
            fail("La configuracion no puede ser nula.");
            return;
        }

        if (setSymbols.length != wheels.size()) {
            fail("La cantidad de simbolos no coincide con las ruedas.");
            return;
        }

        for (int i = 0; i < setSymbols.length; i++) {
            String color = setSymbols[i].toLowerCase().trim();
            if (!symbols.contains(color)) {
                fail("El simbolo no existe.");
                return;
            }

            if (wheels.get(i).isLocked()) {
                Symbol cur = wheels.get(i).getVisibleSymbol();
                if (cur != null && !cur.getColor().equalsIgnoreCase(color)) {
                    fail("Una rueda fijada no puede cambiar.");
                    return;
                }
            }
        }

        for (int i = 0; i < setSymbols.length; i++) {
            wheels.get(i).placeSymbol(setSymbols[i]);
        }

        updateAppearance();
        successful = true;
    }

    /**
     * Retorna los colores de los simbolos de la rueda en orden iniciando por el 1.
     * 
     * @return arreglo con los colores de los simbolos.
     */
    public String[] symbols() {
        String[] result = new String[symbols.size()];
        for (int i = 0; i < symbols.size(); i++) {
            result[i] = symbols.get(i);
        }
        return result;
    }

    /**
     * Retorna los tipos de las ruedas de izquierda a derecha.
     * 
     * @return arreglo con el tipo de cada rueda.
     */
    public String[] wheelTypes() {
        String[] result = new String[wheels.size()];
        for (int i = 0; i < wheels.size(); i++) {
            result[i] = wheels.get(i).getType();
        }
        return result;
    }

    /**
     * Retorna los tipos de los simbolos en el mismo orden que symbols().
     * 
     * @return arreglo con el tipo de cada simbolo.
     */
    public String[] symbolTypes() {
        String[] result = new String[symbolTypes.size()];
        for (int i = 0; i < symbolTypes.size(); i++) {
            result[i] = symbolTypes.get(i);
        }
        return result;
    }

    /**
     * Retorna la cantidad de simbolos diferentes actualmente visibles en las ruedas.
     * 
     * @return cantidad de simbolos visibles unicos.
     */
    public int distinctSymbols() {
        ArrayList<String> distinct = new ArrayList<String>();
        for (Wheel wheel : wheels) {
            Symbol sym = wheel.getVisibleSymbol();
            if (sym != null) {
                String color = sym.getColor().toLowerCase();
                if (!distinct.contains(color)) {
                    distinct.add(color);
                }
            }
        }
        return distinct.size();
    }

    /**
     * Retorna la configuracion de los simbolos visibles de izquierda a derecha.
     * 
     * @return arreglo con los colores visibles en cada rueda.
     */
    public String[] configuration() {
        String[] result = new String[wheels.size()];
        for (int i = 0; i < wheels.size(); i++) {
            Symbol sym = wheels.get(i).getVisibleSymbol();
            result[i] = (sym != null) ? sym.getColor() : "";
        }
        return result;
    }

    /**
     * Verifica si la configuracion actual es ganadora (todas las ruedas con el mismo simbolo).
     * 
     * @return true si es jackpot.
     */
    public boolean isJackpot() {
        boolean jackpot = isJackpotConfiguration();
        updateAppearance();
        return jackpot;
    }

    /**
     * Hace visible el simulador y todos sus elementos.
     */
    public void makeVisible() {
        visible = true;
        Canvas.getCanvas().setVisible(true);
        machine.makeVisible();

        for (Wheel wheel : wheels) {
            wheel.setVisible(true);
        }

        updateAppearance();
        successful = true;
    }

    /**
     * Hace invisible el simulador y sus componentes.
     */
    public void makeInvisible() {
        for (Wheel wheel : wheels) {
            wheel.setVisible(false);
        }

        machine.makeInvisible();
        visible = false;
        successful = true;
    }

    /**
     * Termina el simulador ocultando la ventana.
     */
    public void exit() {
        makeInvisible();
        Canvas.getCanvas().setVisible(false);
        successful = true;
    }

    /**
     * Indica si la ultima operacion fue exitosa.
     * 
     * @return true si la ultima operacion se realizo correctamente.
     */
    public boolean ok() {
        return successful;
    }

    /**
     * Ajusta una posicion al rango permitido [1, maximum].
     */
    private int normalizePosition(int pos, int maximum) {
        if (pos < 1) {
            return 1;
        }
        if (pos > maximum) {
            return maximum;
        }
        return pos;
    }

    /**
     * Registra una operacion fallida y avisa al usuario solo si esta visible.
     */
    private void fail(String message) {
        successful = false;
        if (visible) {
            JOptionPane.showMessageDialog(null, message);
        }
    }

    /**
     * Reorganiza las ruedas horizontalmente segun la cantidad de ruedas.
     */
    private void repositionWheels() {
        int x = 40;
        int y = 80;

        Wheel previous = null;
        for (Wheel wheel : wheels) {
            wheel.setPosition(x, y);
            wheel.setLeftWheel(previous);
            previous = wheel;
            x += 70;
        }

        // Ajustar tamano del fondo de la maquina para que quepan todas las ruedas
        int neededWidth = Math.max(270, x + 20);
        machine.changeSize(180, neededWidth);
    }

    /**
     * Cambia la apariencia de la maquina (verde si gano, magenta por defecto).
     */
    private void updateAppearance() {
        if (isJackpotConfiguration()) {
            machine.changeColor("green");
        } else {
            machine.changeColor("magenta");
        }

        if (visible) {
            for (Wheel wheel : wheels) {
                wheel.setVisible(true);
            }
        }
    }

    /**
     * Verifica si todas las ruedas muestran el mismo simbolo.
     */
    private boolean isJackpotConfiguration() {
        if (wheels.isEmpty() || symbols.isEmpty()) {
            return false;
        }

        Symbol first = wheels.get(0).getVisibleSymbol();
        if (first == null) {
            return false;
        }

        String firstColor = first.getColor();
        for (Wheel wheel : wheels) {
            Symbol current = wheel.getVisibleSymbol();
            if (current == null || !firstColor.equalsIgnoreCase(current.getColor())) {
                return false;
            }
        }

        return true;
    }

    /**
     * Limpia el nombre de un tipo (sin espacios y en minuscula).
     */
    private String normalizeType(String type) {
        if (type == null) {
            return "";
        }
        return type.trim().toLowerCase();
    }

    /**
     * Indica si un arreglo de cadenas contiene el valor dado.
     */
    private boolean contains(String[] values, String value) {
        for (String v : values) {
            if (v.equals(value)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Fabrica una rueda del tipo indicado (el tipo ya fue validado).
     */
    private Wheel createWheel(String type) {
        if (type.equals("lefty")) {
            return new LeftyWheel();
        }
        if (type.equals("rebel")) {
            return new RebelWheel();
        }
        if (type.equals("reverse")) {
            return new ReverseWheel();
        }
        return new Wheel();
    }

    /**
     * Fabrica un simbolo del tipo y color indicados (el tipo ya fue validado).
     */
    private Symbol createSymbol(String type, String color) {
        if (type.equals("ephemeral")) {
            return new EphemeralSymbol(color);
        }
        if (type.equals("shy")) {
            return new ShySymbol(color);
        }
        return new NormalSymbol(color);
    }

    /**
     * Retorna un color CSS para el indice dado.
     */
    private String getColorForIndex(int index) {
        if (index < CSS_COLORS.length) {
            return CSS_COLORS[index];
        }
        return "color" + index;
    }
}
