/**
 * Rueda inversa (reverse): tipo propuesto por el equipo (requisito 19).
 * Gira al reves: cuando se le pide avanzar un paso, retrocede, y viceversa.
 * Se distingue por su marco NARANJA.
 * 
 * @author Reyes y Barragan
 * @version 2026-2
 */
public class ReverseWheel extends Wheel {

    /**
     * Crea una rueda inversa vacia.
     */
    public ReverseWheel() {
        super("orange");
    }

    /**
     * Retorna el nombre del tipo de rueda.
     * 
     * @return "reverse".
     */
    public String getType() {
        return "reverse";
    }

    /**
     * Mueve la rueda un paso pero en el sentido contrario al pedido.
     * 
     * @param forward true para avanzar, false para retroceder.
     */
    protected void moveOneStep(boolean forward) {
        super.moveOneStep(!forward);
    }
}
