import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Pruebas de unidad compartidas del Ciclo 3 para SlotMachineContest.
 * Identificacion de autores: BBRL (Barragan B., Reyes L.).
 * 
 * @author Reyes y Barragan
 * @version 2026-2
 */
public class SlotMachineContestCTest {

    /**
     * Verifica que el algoritmo resuelva la maquina tragamonedas
     * realizando estrictamente menos de 10.000 acciones.
     */
    @Test
    public void accordingBBRLShouldSolveMachineInLessThan10000Actions() {
        int n = 5;
        SlotMachineContest contest = new SlotMachineContest();
        int[][] actions = contest.solve(n);

        assertNotNull(actions);
        assertTrue("Las acciones no deben superar el limite de 10000", actions.length <= 10000);
        assertTrue("Se debe haber ejecutado al menos una accion", actions.length > 0);
    }

    /**
     * Verifica que al finalizar solve(n), la maquina quede en estado Jackpot
     * con exactamente 1 simbolo distinto visible entre todas las ruedas.
     */
    @Test
    public void accordingBBRLShouldReachJackpotState() {
        int n = 4;
        SlotMachineContest contest = new SlotMachineContest();
        contest.solve(n);

        SlotMachine machine = contest.getMachine();
        assertNotNull(machine);
        assertEquals(1, machine.distinctSymbols());
        assertTrue(machine.isJackpot());
    }
}
