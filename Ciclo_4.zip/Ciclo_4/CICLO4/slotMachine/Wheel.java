import java.util.ArrayList;

/**
 * Representa una rueda normal de la maquina tragamonedas.
 * Contiene una lista de simbolos y mantiene uno visible en su ventana.
 * 
 * Es tambien la clase base de los otros tipos de rueda (LeftyWheel, RebelWheel,
 * ReverseWheel), que sobrescriben solo lo que los hace diferentes.
 * Cada tipo se distingue visualmente por el color del marco que rodea la ventana.
 * 
 * @author Reyes y Barragan
 * @version 2026-2
 */
public class Wheel {
    private ArrayList<Symbol> symbols;
    private int visible;
    private Rectangle window;
    private Rectangle frame;
    private int xPosition;
    private int yPosition;
    private boolean isVisible;
    private boolean locked;

    /**
     * Crea una rueda normal vacia (marco gris) en su posicion por defecto.
     */
    public Wheel() {
        this("gray");
    }

    /**
     * Crea una rueda vacia con un marco del color indicado.
     * Lo usan las subclases para distinguirse visualmente.
     * 
     * @param frameColor color del marco de la rueda.
     */
    protected Wheel(String frameColor) {
        symbols = new ArrayList<Symbol>();
        visible = 0;

        xPosition = 40;
        yPosition = 80;

        isVisible = false;
        locked = false;

        // El marco se crea primero para que quede detras de la ventana
        frame = new Rectangle();
        frame.changeColor(frameColor);
        frame.changeSize(68, 68);
        frame.moveHorizontal(-34);
        frame.moveVertical(61);

        window = new Rectangle();
        window.changeColor("black");
        window.changeSize(60, 60);
        window.moveHorizontal(-30);
        window.moveVertical(65);
    }

    /**
     * Retorna el nombre del tipo de rueda.
     * 
     * @return "normal".
     */
    public String getType() {
        return "normal";
    }

    /**
     * Informa a la rueda cual es la rueda que esta a su izquierda.
     * Una rueda normal no la necesita, pero LeftyWheel si.
     * 
     * @param left rueda de la izquierda, o null si no hay ninguna.
     */
    public void setLeftWheel(Wheel left) {
        // Una rueda normal ignora a su vecina.
    }

    /**
     * Indica si esta rueda se deja bloquear.
     * 
     * @return true si se puede bloquear.
     */
    public boolean canBeLocked() {
        return true;
    }

    /**
     * Indica si esta rueda se deja intercambiar de posicion.
     * 
     * @return true si se puede intercambiar.
     */
    public boolean canBeSwapped() {
        return true;
    }

    /**
     * Indica si esta rueda se deja eliminar.
     * 
     * @return true si se puede eliminar.
     */
    public boolean canBeDeleted() {
        return true;
    }

    /**
     * Adiciona un simbolo en la posicion indicada (1-based).
     * 
     * @param pos posicion en la que se inserta el simbolo.
     * @param symbol objeto Symbol a insertar.
     */
    public void addSymbol(int pos, Symbol symbol) {
        if (symbol == null) {
            return;
        }

        if (pos < 1) {
            pos = 1;
        }
        if (pos > symbols.size() + 1) {
            pos = symbols.size() + 1;
        }

        symbols.add(pos - 1, symbol);
        symbol.moveTo(xPosition + 10, yPosition + 10);

        if (symbols.size() == 1) {
            visible = 0;
        }

        updateVisibility();
    }

    /**
     * Elimina un simbolo segun su color.
     * 
     * @param color color del simbolo a eliminar.
     * @return true si se elimino exitosamente.
     */
    public boolean delSymbol(String color) {
        for (int i = 0; i < symbols.size(); i++) {
            if (symbols.get(i).getColor().equalsIgnoreCase(color)) {
                symbols.get(i).makeInvisible();
                symbols.remove(i);

                if (symbols.isEmpty()) {
                    visible = 0;
                } else if (visible >= symbols.size()) {
                    visible = 0;
                }

                updateVisibility();
                return true;
            }
        }
        return false;
    }

    /**
     * Coloca un simbolo como visible segun su color.
     * 
     * @param color color del simbolo a mostrar.
     * @return true si el simbolo existe en la rueda.
     */
    public boolean placeSymbol(String color) {
        for (int i = 0; i < symbols.size(); i++) {
            if (symbols.get(i).getColor().equalsIgnoreCase(color)) {
                select(i);
                return true;
            }
        }
        return false;
    }

    /**
     * Gira la rueda una posicion hacia adelante.
     */
    public void spin() {
        moveOneStep(true);
    }

    /**
     * Gira la rueda una posicion hacia atras.
     */
    public void spinBack() {
        moveOneStep(false);
    }

    /**
     * Gira la rueda un numero determinado de pasos, uno a uno.
     * 
     * @param steps numero de pasos (positivo hacia adelante, negativo hacia atras).
     */
    public void spin(int steps) {
        if (locked || symbols.isEmpty()) {
            return;
        }

        boolean forward = steps > 0;
        int count = Math.abs(steps);
        for (int i = 0; i < count; i++) {
            moveOneStep(forward);
        }
    }

    /**
     * Mueve la rueda UN paso. Todos los giros de la rueda pasan por aqui, por eso
     * los tipos especiales de rueda solo necesitan sobrescribir este metodo.
     * 
     * @param forward true para avanzar, false para retroceder.
     */
    protected void moveOneStep(boolean forward) {
        if (locked || symbols.isEmpty()) {
            return;
        }

        notifySpin();

        int size = symbols.size();
        int newIndex;
        if (forward) {
            newIndex = (visible + 1) % size;
        } else {
            newIndex = (visible - 1 + size) % size;
        }
        select(newIndex);
    }

    /**
     * Avisa a todos los simbolos de la rueda que hubo un giro
     * (por ejemplo, los efimeros se achican).
     */
    protected void notifySpin() {
        for (Symbol s : symbols) {
            s.onSpin();
        }
    }

    /**
     * Retorna el simbolo actualmente visible.
     * 
     * @return objeto Symbol visible o null si esta vacia.
     */
    public Symbol getVisibleSymbol() {
        if (symbols.isEmpty()) {
            return null;
        }
        return symbols.get(visible);
    }

    /**
     * Retorna los colores de los simbolos de la rueda en orden.
     * 
     * @return arreglo de cadenas con los colores.
     */
    public String[] symbols() {
        String[] result = new String[symbols.size()];
        for (int i = 0; i < symbols.size(); i++) {
            result[i] = symbols.get(i).getColor();
        }
        return result;
    }

    /**
     * Retorna la cantidad de simbolos en la rueda.
     * 
     * @return numero de simbolos.
     */
    public int size() {
        return symbols.size();
    }

    /**
     * Verifica si la rueda contiene un simbolo con el color dado.
     * 
     * @param color color a buscar.
     * @return true si existe.
     */
    public boolean contains(String color) {
        for (Symbol s : symbols) {
            if (s.getColor().equalsIgnoreCase(color)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Bloquea la rueda impidiendo su giro.
     */
    public void lock() {
        locked = true;
    }

    /**
     * Desbloquea la rueda permitiendo su giro.
     */
    public void unlock() {
        locked = false;
    }

    /**
     * Indica si la rueda esta bloqueada.
     * 
     * @return true si esta bloqueada.
     */
    public boolean isLocked() {
        return locked;
    }

    /**
     * Cambia la visibilidad grafica de la rueda.
     * 
     * @param visible true para hacer visible, false para ocultar.
     */
    public void setVisible(boolean visible) {
        isVisible = visible;
        if (visible) {
            frame.makeVisible();
            window.makeVisible();
            updateVisibility();
        } else {
            frame.makeInvisible();
            window.makeInvisible();
            hideSymbols();
        }
    }

    /**
     * Reposiciona la rueda y sus simbolos en coordenadas (x, y).
     * 
     * @param x nueva coordenada horizontal.
     * @param y nueva coordenada vertical.
     */
    public void setPosition(int x, int y) {
        int horizontal = x - xPosition;
        int vertical = y - yPosition;

        // Primero el marco y despues la ventana, para que la ventana quede encima
        frame.moveHorizontal(horizontal);
        frame.moveVertical(vertical);
        window.moveHorizontal(horizontal);
        window.moveVertical(vertical);

        xPosition = x;
        yPosition = y;

        for (Symbol symbol : symbols) {
            symbol.moveTo(xPosition + 10, yPosition + 10);
        }

        updateVisibility();
    }

    /**
     * Selecciona el simbolo de la posicion indicada como el de la ventana.
     * Si es un simbolo distinto al actual, se le avisa que fue seleccionado.
     */
    private void select(int newIndex) {
        if (newIndex != visible) {
            visible = newIndex;
            symbols.get(visible).onSelected();
        }
        updateVisibility();
    }

    /**
     * Actualiza la visibilidad mostrando unicamente el simbolo en la ventana visible.
     */
    private void updateVisibility() {
        hideSymbols();
        if (isVisible && !symbols.isEmpty()) {
            symbols.get(visible).makeVisible();
        }
    }

    /**
     * Oculta todos los simbolos de la rueda.
     */
    private void hideSymbols() {
        for (Symbol s : symbols) {
            s.makeInvisible();
        }
    }
}
