/**
 * Rueda zurda (lefty): si tiene una rueda a su izquierda, cada vez que gira
 * COPIA el simbolo que muestra esa rueda. Si no tiene ninguna a su izquierda
 * (esta en la primera posicion), gira como una rueda normal.
 * Se distingue por su marco AZUL.
 * 
 * @author Reyes y Barragan
 * @version 2026-2
 */
public class LeftyWheel extends Wheel {
    private Wheel left;

    /**
     * Crea una rueda zurda vacia.
     */
    public LeftyWheel() {
        super("blue");
        left = null;
    }

    /**
     * Retorna el nombre del tipo de rueda.
     * 
     * @return "lefty".
     */
    public String getType() {
        return "lefty";
    }

    /**
     * Guarda la rueda que esta a su izquierda.
     * 
     * @param left rueda de la izquierda, o null si no hay ninguna.
     */
    public void setLeftWheel(Wheel left) {
        this.left = left;
    }

    /**
     * Si hay rueda a la izquierda copia su simbolo; si no, gira normalmente.
     * 
     * @param forward true para avanzar, false para retroceder.
     */
    protected void moveOneStep(boolean forward) {
        if (left == null) {
            super.moveOneStep(forward);
            return;
        }

        if (isLocked() || size() == 0) {
            return;
        }

        notifySpin();
        Symbol leftSymbol = left.getVisibleSymbol();
        if (leftSymbol != null) {
            placeSymbol(leftSymbol.getColor());
        }
    }
}
