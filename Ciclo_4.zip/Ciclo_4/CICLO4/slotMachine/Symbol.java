/**
 * Clase base de todos los simbolos de la maquina tragamonedas.
 * Cada simbolo se identifica por un color (estandar CSS) y tiene un tipo.
 * 
 * Los tipos concretos (NormalSymbol, EphemeralSymbol, ShySymbol) heredan de esta
 * clase y definen como se dibujan y como reaccionan cuando la rueda gira o
 * cuando el simbolo es seleccionado.
 * 
 * @author Reyes y Barragan
 * @version 2026-2
 */
public abstract class Symbol {
    private String color;

    /**
     * Crea un simbolo con el color indicado.
     * 
     * @param color color del simbolo (estandar CSS).
     */
    public Symbol(String color) {
        this.color = color;
    }

    /**
     * Retorna el color del simbolo.
     * 
     * @return color del simbolo.
     */
    public String getColor() {
        return color;
    }

    /**
     * Retorna el nombre del tipo de simbolo (por ejemplo "normal").
     * 
     * @return nombre del tipo.
     */
    public abstract String getType();

    /**
     * Hace visible la representacion grafica del simbolo.
     */
    public abstract void makeVisible();

    /**
     * Hace invisible la representacion grafica del simbolo.
     */
    public abstract void makeInvisible();

    /**
     * Mueve el simbolo a una posicion (x, y).
     * 
     * @param x nueva posicion horizontal.
     * @param y nueva posicion vertical.
     */
    public abstract void moveTo(int x, int y);

    /**
     * Se ejecuta cada vez que la rueda a la que pertenece el simbolo gira un paso.
     * Por omision no hace nada; los tipos especiales lo sobrescriben.
     */
    public void onSpin() {
        // Un simbolo normal no reacciona al giro.
    }

    /**
     * Se ejecuta cada vez que el simbolo es seleccionado en la rueda, es decir,
     * cuando pasa a ser el simbolo de la ventana.
     * Por omision no hace nada; los tipos especiales lo sobrescriben.
     */
    public void onSelected() {
        // Un simbolo normal no reacciona a la seleccion.
    }
}
