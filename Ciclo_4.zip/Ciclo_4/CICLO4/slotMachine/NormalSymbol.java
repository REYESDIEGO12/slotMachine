/**
 * Simbolo normal: un circulo de color que siempre se ve igual.
 * Es el simbolo que se usaba en los ciclos anteriores.
 * 
 * @author Reyes y Barragan
 * @version 2026-2
 */
public class NormalSymbol extends Symbol {
    private static final int SIZE = 40;

    private Circle figure;
    private int xPosition;
    private int yPosition;

    /**
     * Crea un simbolo normal con el color indicado.
     * 
     * @param color color del simbolo (estandar CSS).
     */
    public NormalSymbol(String color) {
        super(color);
        figure = new Circle();
        figure.changeColor(color);
        figure.changeSize(SIZE);

        // Posicion por defecto de un Circle
        xPosition = 20;
        yPosition = 15;
    }

    /**
     * Retorna el nombre del tipo.
     * 
     * @return "normal".
     */
    public String getType() {
        return "normal";
    }

    /**
     * Hace visible el circulo.
     */
    public void makeVisible() {
        figure.makeVisible();
    }

    /**
     * Hace invisible el circulo.
     */
    public void makeInvisible() {
        figure.makeInvisible();
    }

    /**
     * Mueve el circulo a la posicion (x, y).
     * 
     * @param x nueva posicion horizontal.
     * @param y nueva posicion vertical.
     */
    public void moveTo(int x, int y) {
        figure.moveHorizontal(x - xPosition);
        figure.moveVertical(y - yPosition);
        xPosition = x;
        yPosition = y;
    }
}
