import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Pruebas de unidad compartidas del Ciclo 2.
 * 
 * @author Reyes y Barragan
 * @version 2026-2
 */
public class SlotMachineCC2Test {

    /**
     * Verifica que dos ruedas cambien de posicion al realizar un intercambio.
     */
    @Test
    public void accordingBBRLShouldSwapWheels() {
        SlotMachine slotMachine = new SlotMachine();

        slotMachine.addSymbol(1, "red");
        slotMachine.addSymbol(2, "blue");

        slotMachine.addWheel(1);
        slotMachine.addWheel(2);

        slotMachine.placeSymbol(1, "red");
        slotMachine.placeSymbol(2, "blue");

        slotMachine.swap(1, 2);

        assertArrayEquals(new String[]{"blue", "red"}, slotMachine.configuration());
    }

    /**
     * Verifica que una rueda avance exactamente el numero de pasos indicado.
     */
    @Test
    public void accordingBBRLShouldSpinTheSpecifiedNumberOfSteps() {
        SlotMachine slotMachine = new SlotMachine();

        slotMachine.addSymbol(1, "red");
        slotMachine.addSymbol(2, "blue");
        slotMachine.addSymbol(3, "green");

        slotMachine.addWheel(1);
        slotMachine.placeSymbol(1, "red");

        slotMachine.spin(1, 2);

        assertArrayEquals(new String[]{"green"}, slotMachine.configuration());
    }
}
