/**
 * Rueda rebelde (rebel): no se deja bloquear, ni intercambiar, ni eliminar.
 * Se distingue por su marco ROJO.
 * 
 * @author Reyes y Barragan
 * @version 2026-2
 */
public class RebelWheel extends Wheel {

    /**
     * Crea una rueda rebelde vacia.
     */
    public RebelWheel() {
        super("red");
    }

    /**
     * Retorna el nombre del tipo de rueda.
     * 
     * @return "rebel".
     */
    public String getType() {
        return "rebel";
    }

    /**
     * Una rueda rebelde no se deja bloquear.
     * 
     * @return false siempre.
     */
    public boolean canBeLocked() {
        return false;
    }

    /**
     * Una rueda rebelde no se deja intercambiar.
     * 
     * @return false siempre.
     */
    public boolean canBeSwapped() {
        return false;
    }

    /**
     * Una rueda rebelde no se deja eliminar.
     * 
     * @return false siempre.
     */
    public boolean canBeDeleted() {
        return false;
    }

    /**
     * Ignora la orden de bloqueo: la rueda rebelde nunca queda bloqueada.
     */
    public void lock() {
        // No hace nada a proposito.
    }
}
