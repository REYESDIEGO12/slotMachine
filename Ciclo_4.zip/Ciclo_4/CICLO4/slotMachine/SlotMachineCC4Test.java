import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Pruebas de unidad compartidas del Ciclo 4 (tipos de ruedas y simbolos).
 * Identificacion de autores: BBRL (Barragan B., Reyes L.).
 * 
 * @author Reyes y Barragan
 * @version 2026-2
 */
public class SlotMachineCC4Test {

    /**
     * Verifica que una rueda lefty copie el simbolo de la rueda que tiene a su izquierda.
     */
    @Test
    public void accordingBBRLShouldLeftyWheelCopyTheWheelOnItsLeft() {
        SlotMachine slotMachine = new SlotMachine();
        slotMachine.addSymbol(1, "red");
        slotMachine.addSymbol(2, "blue");
        slotMachine.addWheel("normal", 1);
        slotMachine.addWheel("lefty", 2);
        slotMachine.placeSymbol(1, "red");
        slotMachine.placeSymbol(2, "blue");

        slotMachine.spin(2, 1);

        assertArrayEquals(new String[]{"red", "red"}, slotMachine.configuration());
    }

    /**
     * Verifica que una rueda rebel no se deje eliminar.
     */
    @Test
    public void accordingBBRLShouldRebelWheelNotBeDeleted() {
        SlotMachine slotMachine = new SlotMachine();
        slotMachine.addSymbol(1, "red");
        slotMachine.addWheel("rebel", 1);

        slotMachine.delWheel(1);

        assertFalse(slotMachine.ok());
        assertArrayEquals(new String[]{"rebel"}, slotMachine.wheelTypes());
    }
}
